#include <initializer_list>
#include <cmath>
#include <cstdio>
#include <cassert>
#include "physics/convex_collision.hpp"
using RbV = Tyra::CollisionV3;
inline RbV rbV(float x, float y, float z) {
  RbV r;
  r.x = x, r.y = y, r.z = z;
  return r;
}
inline RbV rbAdd(RbV a, RbV b) { return rbV(a.x + b.x, a.y + b.y, a.z + b.z); }
inline RbV rbSub(RbV a, RbV b) { return rbV(a.x - b.x, a.y - b.y, a.z - b.z); }
inline RbV rbMul(RbV a, float s) { return rbV(a.x * s, a.y * s, a.z * s); }
inline float rbDot(RbV a, RbV b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline RbV rbCross(RbV a, RbV b) {
  return rbV(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z,
             a.x * b.y - a.y * b.x);
}
// 3x3 row-major
inline RbV rbMat(const float* m, RbV v) {
  return rbV(m[0] * v.x + m[1] * v.y + m[2] * v.z,
             m[3] * v.x + m[4] * v.y + m[5] * v.z,
             m[6] * v.x + m[7] * v.y + m[8] * v.z);
}
inline RbV rbMatT(const float* m, RbV v) {
  return rbV(m[0] * v.x + m[3] * v.y + m[6] * v.z,
             m[1] * v.x + m[4] * v.y + m[7] * v.z,
             m[2] * v.x + m[5] * v.y + m[8] * v.z);
}

struct RbCand {
  RbV n, p;
  float depth;
};

// Up to four points that span a contact patch: the deepest, the one
// farthest from it, the one farthest from that segment, then the one that
// adds the most area. A crate face flat on the ground keeps its four
// corners; a ring of cylinder rim points keeps a stable quadrilateral.
inline int rbReduce(const RbCand* in, int n, RbCand* out) {
  if (n <= 4) {
    for (int i = 0; i < n; ++i) out[i] = in[i];
    return n;
  }
  int pick[4] = {0, -1, -1, -1};
  for (int i = 1; i < n; ++i)
    if (in[i].depth > in[pick[0]].depth) pick[0] = i;
  float best = -1.0F;
  for (int i = 0; i < n; ++i) {
    const RbV d = rbSub(in[i].p, in[pick[0]].p);
    const float l = rbDot(d, d);
    if (l > best) best = l, pick[1] = i;
  }
  best = -1.0F;
  const RbV ab = rbSub(in[pick[1]].p, in[pick[0]].p);
  for (int i = 0; i < n; ++i) {
    const RbV c = rbCross(ab, rbSub(in[i].p, in[pick[0]].p));
    const float l = rbDot(c, c);
    if (l > best) best = l, pick[2] = i;
  }
  best = -1.0F;
  for (int i = 0; i < n; ++i) {
    if (i == pick[0] || i == pick[1] || i == pick[2]) continue;
    float area = 0.0F;
    for (int e = 0; e < 3; ++e) {
      const RbV a = rbSub(in[pick[e]].p, in[i].p);
      const RbV b = rbSub(in[pick[(e + 1) % 3]].p, in[i].p);
      const RbV c = rbCross(a, b);
      area += rbDot(c, c);
    }
    if (area > best) best = area, pick[3] = i;
  }
  int m = 0;
  for (int k = 0; k < 4; ++k) {
    if (pick[k] < 0) continue;
    bool dup = false;
    for (int e = 0; e < k; ++e) dup = dup || pick[e] == pick[k];
    if (!dup) out[m++] = in[pick[k]];
  }
  return m;
}

// The deepest face of a convex body (planes in its own centre-of-mass
// frame) that point `l` is inside; -1 when outside any of them.
inline int rbInsideHull(const float* lp, int np, RbV l, float* depth) {
  int best = -1;
  float bd = 1e30F;
  for (int k = 0; k < np; ++k) {
    const float* pl = lp + k * 4;
    const float d = pl[3] - (pl[0] * l.x + pl[1] * l.y + pl[2] * l.z);
    if (d <= 0.0F) return -1;
    if (d < bd) bd = d, best = k;
  }
  *depth = bd;
  return best;
}


struct Body {float radius=.866026f;const float* lp;int planes=6;};
struct Step {RbV x1,wv[8];int nv=8;float R1[9]={1,0,0,0,1,0,0,0,1};};
int corners(const Step&A,const Body&Ba,const Step&Bs,const Body&Bj,RbCand*out){RbCand cand[48];int n=0;
        for (int k = 0; k < A.nv && n < 48; ++k) {
          const RbV rel = rbSub(A.wv[k], Bs.x1);
          if (rbDot(rel, rel) > Bj.radius * Bj.radius) continue;
          float depth;
          const int f = rbInsideHull(Bj.lp,Bj.planes,rbMatT(Bs.R1,rel),&depth);
          if (f < 0) continue;
          const float* pl = Bj.lp + f * 4;
          cand[n].n = rbMat(Bs.R1, rbV(pl[0], pl[1], pl[2]));
          cand[n].p = A.wv[k];
          cand[n].depth = depth;
          ++n;
        }
        for (int k = 0; k < Bs.nv && n < 48; ++k) {
          const RbV rel = rbSub(Bs.wv[k], A.x1);
          if (rbDot(rel, rel) > Ba.radius * Ba.radius) continue;
          float depth;
          const int f = rbInsideHull(Ba.lp,Ba.planes,rbMatT(A.R1,rel),&depth);
          if (f < 0) continue;
          const float* pl = Ba.lp + f * 4;
          cand[n].n = rbMul(rbMat(A.R1, rbV(pl[0], pl[1], pl[2])), -1.0F);
          cand[n].p = Bs.wv[k];
          cand[n].depth = depth;
          ++n;
        }
 return rbReduce(cand,n,out);}
int main(){
 float planes[]={1,0,0,.5f,-1,0,0,.5f,0,1,0,.5f,0,-1,0,.5f,0,0,1,.5f,0,0,-1,.5f};
 RbV ns[]={{1,0,0},{-1,0,0},{0,1,0},{0,-1,0},{0,0,1},{0,0,-1}},edges[]={{1,0,0},{0,1,0},{0,0,1}};
 Body body;body.lp=planes;int bad=0,total=0;
 puts("offset_x,offset_z,corner_contacts,vertical_contacts,sat_depth,max_corner_depth");
 for(float dx:{-.001f,-.0001f,0.f,.0001f,.001f})for(float dz:{-.001f,-.0001f,0.f,.0001f,.001f}){
  Step A{},B{};A.x1={dx,.9f,dz};int k=0;
  for(float x:{-.5f,.5f})for(float y:{-.5f,.5f})for(float z:{-.5f,.5f}){A.wv[k]=rbAdd(A.x1,{x,y,z});B.wv[k++]={x,y,z};}
  Tyra::ConvexView av={A.wv,8,ns,6,edges,3},bv={B.wv,8,ns,6,edges,3};Tyra::ConvexContact sat;
  assert(Tyra::convexMotionContact(av,bv,{0,0,0},{0,0,0},sat));assert(fabsf(sat.normal.y)>.99f);assert(fabsf(sat.depth-.1f)<1e-6f);
  RbCand c[4];int n=corners(A,body,B,body,c),vertical=0;float maxdepth=0;
  for(int j=0;j<n;j++){vertical+=fabsf(c[j].n.y)>.5f;maxdepth=fmaxf(maxdepth,c[j].depth);}
  if(n>0 && vertical==0)bad++;total++;
  printf("%.7g,%.7g,%d,%d,%.7g,%.7g\n",dx,dz,n,vertical,sat.depth,maxdepth);
  if(dx==0 || dz==0)assert(n==0);else assert(n==2 && vertical==0 && maxdepth<.002f);
 }
 assert(bad==16 && total==25);fprintf(stderr,"REPRODUCED: %d/%d offsets generate horizontal-only corner manifolds despite vertical SAT minimum; boundary controls fall back to SAT.\n",bad,total);
}
