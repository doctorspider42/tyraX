#include "project.hpp"
static_assert(sizeof(project::ProjectSettings)==1008);
