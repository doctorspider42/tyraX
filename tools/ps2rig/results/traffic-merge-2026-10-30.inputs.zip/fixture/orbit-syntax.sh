#!/usr/bin/env bash
set -euo pipefail
sdk=/home/spider/.cache/tyrax/native/toolchains/eff2c8918589264d49aa9a0f
compiler="$sdk/ee/bin/mips64r5900el-ps2-elf-g++"
project=/mnt/f/Projects/tyra-editor/.tmp/tests/traffic-pr285/merge-format
engine=/mnt/f/Projects/tyra-editor/.tmp/worktrees/ps2-collision/vendor/tyra/engine
for source in terrain_game.cpp gen/game_scene.gen.cpp gen/game_lighting.gen.cpp gen/game_collision.gen.cpp gen/game_vehicles.gen.cpp gen/game_physics.gen.cpp gen/scene_objects.gen.cpp; do
 "$compiler" -D_EE -G0 -std=gnu++17 -fsyntax-only -I"$project/inc" -I"$engine/inc" -I"$sdk/ps2sdk/ee/include" -I"$sdk/ps2sdk/common/include" -I"$sdk/ps2sdk/ports/include" "$project/src/$source"
 printf 'PASS orbit syntax: %s\n' "$source"
done
