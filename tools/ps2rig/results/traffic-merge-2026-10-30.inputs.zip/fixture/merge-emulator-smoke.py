import importlib.util, pathlib, sys
source=pathlib.Path('F:/Projects/tyra-editor/.tmp/worktrees/ps2-collision/.agents/skills/tyra-testing/scripts/pcsx2-capture.py')
spec=importlib.util.spec_from_file_location('merge_capture',source);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
prepare=m.prepare_datapath
def software(dp,ini,slot):
 root=prepare(dp,ini,slot);p=root/'inis/PCSX2.ini';text=p.read_text(encoding='utf-8');text=m.ini_set(text,'EmuCore/GS','Renderer','13');p.write_bytes(text.encode('utf-8'));return root
m.prepare_datapath=software
sys.argv=[str(source),'run','F:/Projects/tyra-editor/.tmp/tests/traffic-pr285/merged-game/bin/vehicle-playground.elf','--states','1','--boot-wait','15','--work-root','F:/Projects/tyra-editor/.tmp/tests/traffic-pr285/pcsx2-merge','--out','F:/Projects/tyra-editor/.tmp/artifacts/traffic-pr285/pcsx2-merge','--slot','285','--stage']
m.main()
