#include <cassert>
#include <cmath>
#include <cstdio>
#include <vector>
#include "physics/vu0_sat.hpp"
namespace Vehicle_playground { namespace CB {inline int frame=0;inline bool finished=false;} namespace runtime_detail {
using RbV = Tyra::CollisionV3;
inline RbV rbV(float x, float y, float z) {
  RbV r;
  r.x = x, r.y = y, r.z = z;
  return r;
}
inline RbV rbAdd(RbV a, RbV b) { return rbV(a.x + b.x, a.y + b.y, a.z + b.z); }
inline RbV rbSub(RbV a, RbV b) { return rbV(a.x - b.x, a.y - b.y, a.z - b.z); }
inline RbV rbMul(RbV a, float s) { return rbV(a.x * s, a.y * s, a.z * s); }
inline float rbDot(RbV a, RbV b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline RbV rbCross(RbV a, RbV b) {
  return rbV(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z,
             a.x * b.y - a.y * b.x);
}
// 3x3 row-major
inline RbV rbMat(const float* m, RbV v) {
  return rbV(m[0] * v.x + m[1] * v.y + m[2] * v.z,
             m[3] * v.x + m[4] * v.y + m[5] * v.z,
             m[6] * v.x + m[7] * v.y + m[8] * v.z);
}
inline RbV rbMatT(const float* m, RbV v) {
  return rbV(m[0] * v.x + m[3] * v.y + m[6] * v.z,
             m[1] * v.x + m[4] * v.y + m[7] * v.z,
             m[2] * v.x + m[5] * v.y + m[8] * v.z);
}

}
}
#include "F:/Projects/tyra-editor/.tmp/worktrees/ps2-collision/tools/ps2rig/vehicle_contacts_probe.hpp"
namespace Vehicle_playground {using namespace runtime_detail;
struct RbContact {
  int other, history; // stable other object (-1 terrain), history record
  short a, b;     // RbStep indices; b = -1 is the world
  RbV n;          // pushes a away from b
  RbV p;          // world point
  float depth;
  float vnPred;   // normal velocity at creation (predicted motion)
  float bounceTarget;
  float mu;
  float kn;
  float jn, jp;
  RbV ft;         // accumulated friction impulse
  RbV ra, rb;
};
struct RbStep {int obj=0;float invMass=0,bounce=0,friction=0;bool grounded=false;RbV x1{},v{},w{},vp{},wp{};float invIw[9]{};};
namespace ZeroFrictionProbe {inline void record(bool,unsigned,unsigned){}}
constexpr int PHYS_ITERATIONS=6,PHYS_POS_ITERATIONS=3;constexpr float PHYS_SLOP=.005f,PHYS_BAUMGARTE=.5f;
void solve(std::vector<RbStep>& steps,std::vector<RbContact>& contacts){
 const int nc=int(contacts.size());const float bounceThreshold=0;const bool warmStart=false,skipZeroFriction=true;unsigned zeroFrictionSkipped=0;
 auto restoreContact=[](RbContact&){};
  for (int k = 0; k < nc; ++k) {
    RbContact& c = contacts[k];
    RbStep& A = steps[c.a];
    c.ra = rbSub(c.p, A.x1);
    RbV vrel = rbAdd(A.v, rbCross(A.w, c.ra));
    const RbV ca = rbCross(c.ra, c.n);
    float kn = A.invMass + rbDot(rbCross(rbMat(A.invIw, ca), c.ra), c.n);
    float e = A.bounce, f = A.friction;
    if (c.b >= 0) {
      RbStep& Bs = steps[c.b];
      c.rb = rbSub(c.p, Bs.x1);
      vrel = rbSub(vrel, rbAdd(Bs.v, rbCross(Bs.w, c.rb)));
      const RbV cb = rbCross(c.rb, c.n);
      kn += Bs.invMass + rbDot(rbCross(rbMat(Bs.invIw, cb), c.rb), c.n);
      if (Bs.bounce > e) e = Bs.bounce;
      f = 0.5F * (f + Bs.friction);
    } else {
      c.rb = rbV(0.0F, 0.0F, 0.0F);
    }
    c.kn = kn > 1e-9F ? kn : 1e-9F;
    c.vnPred = rbDot(vrel, c.n);
    c.bounceTarget = -c.vnPred > bounceThreshold ? -e * c.vnPred : 0.0F;
    // Coulomb friction coefficient from the authored 0..1 "Friction".
    c.mu = 0.05F + 0.95F * f;
    c.jn = c.jp = 0.0F;
    c.ft = rbV(0.0F, 0.0F, 0.0F);
    restoreContact(c);
    if (c.n.y > 0.5F) A.grounded = true;
    if (c.b >= 0 && c.n.y < -0.5F) steps[c.b].grounded = true;
  }
  auto applyImpulse = [&](RbContact& c, RbV P) {
    RbStep& A = steps[c.a];
    const RbV beforeA=A.v,beforeB=c.b>=0?steps[c.b].v:rbV(0,0,0);
    A.v = rbAdd(A.v, rbMul(P, A.invMass));
    A.w = rbAdd(A.w, rbMat(A.invIw, rbCross(c.ra, P)));
    if (c.b >= 0) {
      RbStep& Bs = steps[c.b];
      Bs.v = rbAdd(Bs.v, rbMul(P, Bs.invMass));
      Bs.w = rbSub(Bs.w, rbMat(Bs.invIw, rbCross(c.rb, P)));
      if(VehicleContacts::isCar(A.obj) || VehicleContacts::isCar(Bs.obj))
        VehicleContacts::impulse(beforeA,beforeB,A.v,Bs.v,A.invMass,Bs.invMass,P);
    }
  };
  auto relVel = [&](const RbContact& c) {
    const RbStep& A = steps[c.a];
    RbV v = rbAdd(A.v, rbCross(A.w, c.ra));
    if (c.b >= 0) {
      const RbStep& Bs = steps[c.b];
      v = rbSub(v, rbAdd(Bs.v, rbCross(Bs.w, c.rb)));
    }
    return v;
  };
  if(warmStart)for(auto& c:contacts)applyImpulse(c,rbAdd(rbMul(c.n,c.jn),c.ft));
  for (int it = 0; it < PHYS_ITERATIONS; ++it)
    for (int k = 0; k < nc; ++k) {
      RbContact& c = contacts[k];
      RbV vrel = relVel(c);
      const float vn = rbDot(vrel, c.n);
      float nj = c.jn + (c.bounceTarget - vn) / c.kn;
      if (nj < 0.0F) nj = 0.0F;
      const float dj = nj - c.jn;
      c.jn = nj;
      if (dj != 0.0F) applyImpulse(c, rbMul(c.n, dj));
      // A zero-radius Coulomb disk and no prior tangent impulse imply zero
      // friction change. Keep all normal/position solves and contact records.
      if(skipZeroFriction&&c.jn==0&&c.ft.x==0&&c.ft.y==0&&c.ft.z==0){++zeroFrictionSkipped;continue;}
      // friction, against whatever tangential slip is left
      vrel = relVel(c);
      const RbV vt = rbSub(vrel, rbMul(c.n, rbDot(vrel, c.n)));
      const float vtl2 = rbDot(vt, vt);
      if (vtl2 < 1e-14F) continue;
      const float vtl = sqrtf(vtl2);
      const RbV t = rbMul(vt, 1.0F / vtl);
      const RbStep& A = steps[c.a];
      float kt = A.invMass +
                 rbDot(rbCross(rbMat(A.invIw, rbCross(c.ra, t)), c.ra), t);
      if (c.b >= 0) {
        const RbStep& Bs = steps[c.b];
        kt += Bs.invMass +
              rbDot(rbCross(rbMat(Bs.invIw, rbCross(c.rb, t)), c.rb), t);
      }
      if (kt < 1e-9F) continue;
      RbV nf = rbAdd(c.ft, rbMul(t, -vtl / kt));
      const float lim = c.mu * c.jn;
      const float nfl2 = rbDot(nf, nf);
      if (nfl2 > lim * lim) nf = rbMul(nf, lim / sqrtf(nfl2));
      applyImpulse(c, rbSub(nf, c.ft));
      c.ft = nf;
    }
  ZeroFrictionProbe::record(skipZeroFriction,unsigned(nc)*PHYS_ITERATIONS,zeroFrictionSkipped);
  // Split impulse: the overlap still left after the velocity solve is
  // removed through pseudo velocities that move the body and are then
  // forgotten, so pushing a body out of the ground never launches it.
  for (int it = 0; it < PHYS_POS_ITERATIONS; ++it)
    for (int k = 0; k < nc; ++k) {
      RbContact& c = contacts[k];
      RbStep& A = steps[c.a];
      const float vnNow = rbDot(relVel(c), c.n);
      const float remaining = c.depth - (vnNow - c.vnPred);
      const float target =
          remaining > PHYS_SLOP ? PHYS_BAUMGARTE * (remaining - PHYS_SLOP) : 0.0F;
      RbV vp = rbAdd(A.vp, rbCross(A.wp, c.ra));
      if (c.b >= 0) {
        const RbStep& Bs = steps[c.b];
        vp = rbSub(vp, rbAdd(Bs.vp, rbCross(Bs.wp, c.rb)));
      }
      float nj = c.jp + (target - rbDot(vp, c.n)) / c.kn;
      if (nj < 0.0F) nj = 0.0F;
      const float dj = nj - c.jp;
      c.jp = nj;
      if (dj == 0.0F) continue;
      const RbV P = rbMul(c.n, dj);
      A.vp = rbAdd(A.vp, rbMul(P, A.invMass));
      A.wp = rbAdd(A.wp, rbMat(A.invIw, rbCross(c.ra, P)));
      if (c.b >= 0) {
        RbStep& Bs = steps[c.b];
        Bs.vp = rbSub(Bs.vp, rbMul(P, Bs.invMass));
        Bs.wp = rbSub(Bs.wp, rbMat(Bs.invIw, rbCross(c.rb, P)));
      }
    }
}
float energy(const std::vector<RbStep>& b){float result=0;for(const auto& s:b){if(s.invMass>0)result+=.5f*rbDot(s.v,s.v)/s.invMass;if(s.invIw[4]>0)result+=.5f*s.w.y*s.w.y/s.invIw[4];}return result;}
void run(float ma,float mb,float va,float vb,float bounce,float offset){
 std::vector<RbStep>b(2);b[0].obj=0;b[1].obj=1;b[0].invMass=1/ma;b[1].invMass=mb>0?1/mb:0;
 b[0].v={0,0,va};b[1].v={0,0,vb};b[0].bounce=b[1].bounce=bounce;
 b[0].invIw[4]=1/(ma*2);b[1].invIw[4]=mb>0?1/(mb*2):0;
 std::vector<RbContact>c(1);c[0].a=0;c[0].b=1;c[0].n={0,0,-1};c[0].p={offset,0,0};
 float momentum=ma*va+mb*vb,ke=energy(b);
 VehicleContacts::current={};solve(b,c);
 if(mb>0){assert(fabsf(ma*b[0].v.z+mb*b[1].v.z-momentum)<.001f);assert(fabsf(ma*2*b[0].w.y+mb*2*b[1].w.y)<.001f);assert(energy(b)<=ke+.001f);}
 if(offset==0 && mb>0){float av=(ma*va+mb*vb-mb*bounce*(va-vb))/(ma+mb);float bv=(ma*va+mb*vb+ma*bounce*(va-vb))/(ma+mb);assert(fabsf(b[0].v.z-av)<1e-5f);assert(fabsf(b[1].v.z-bv)<1e-5f);}
 if(offset!=0)assert(b[0].w.y!=0);assert(VehicleContacts::current.errors==0);
}
}
int main(){using namespace Vehicle_playground;Tyra::vu0SatVerify=true;VehicleContacts::enabled=true;VehicleContacts::of={0,-1};
 for(float a:{1.f,10.f,1500.f})for(float b:{1.f,20.f,1000.f})for(float e:{0.f,.4f,1.f})for(float off:{0.f,.5f})run(a,b,.2f,-.05f,e,off);
 run(1500,0,.2f,0,.2f,.5f);
 puts("PASS: 54 actual legacy-solver car/prop cases: analytic restitution, finite-mass linear/yaw momentum, no kinetic-energy gain, off-centre yaw response; immovable partner guard");
}
