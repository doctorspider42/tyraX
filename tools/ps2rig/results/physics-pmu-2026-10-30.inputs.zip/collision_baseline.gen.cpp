#include "debug/vu0_sat_precision.hpp"
#include "debug/vu0_sat_stream.hpp"
#include "debug/vu0_sat_probe.hpp"
#include "game_runtime.gen.hpp"
#include "debug/contact_solver_probe.hpp"
#include <stdlib.h>
namespace Vehicle_playground {
void TerrainGame::updateObjectPhysicsBaseline() {
  // GRAVITY is units/s^2; velocities are per-frame displacements.
  const float gravityPerFrame = GRAVITY * g_frameDt * g_frameDt;
  // Below this approach speed a contact is resting and does not bounce -
  // otherwise gravity's own frame of fall would buzz a crate on the floor.
  const float bounceThreshold = 3.0F * gravityPerFrame + 0.004F;
  const int count = (int)runtimeObjects.size();
  const float wakeSpeed = sqrtf(PHYS_WAKE_SPEED2);
  const bool coherence = TYRA_PHYSICS_COHERENCE != 0;
  const bool warmStart = TYRA_PHYSICS_WARM_START != 0;
  const bool useIslands = TYRA_PHYSICS_ISLANDS != 0;
  static Tyra::ContactHistory contactHistory;
  static Tyra::SeparatingAxisHistory axisHistory;
  static Tyra::ContactIslands islands;
  static std::vector<unsigned char> islandQuiet,islandReady;
  static std::vector<int> lastIsland;
  static unsigned temporalGeneration = ~0u;
  if (useIslands && (temporalGeneration != sceneGeneration || lastIsland.size() != runtimeObjects.size())) {
    lastIsland.assign(runtimeObjects.size(), -1);
    temporalGeneration = sceneGeneration;
  }
  if(warmStart) contactHistory.begin(sceneGeneration,g_frameDt);
  if(coherence) axisHistory.begin(sceneGeneration);

  struct SatGeometry { bool valid=false; RbV normals[44],edges[66]; };
  static std::vector<SatGeometry> satGeometry;
  struct WorldGeometry {
    bool valid=false; unsigned revision=0; float key[14];
    V3 ax,ay,az; float matrix[9],half[3]; RbV centre,extent,vertices[8];
    Tyra::CollisionObb box;
  };
  static std::vector<WorldGeometry> worldGeometry;
  static unsigned worldGeometryGeneration=~0u;
  auto worldShape = [&](int index,const CollisionBox& cb) -> WorldGeometry& {
    auto& g=worldGeometry[index];const auto& d=runtimeObjects[index].data;
    const float key[14]={d.position[0],d.position[1],d.position[2],
      d.rotation[0],d.rotation[1],d.rotation[2],cb.center[0],cb.center[1],cb.center[2],
      cb.half[0],cb.half[1],cb.half[2],cb.yaw,float(d.type)};
    bool same=g.valid;
    for(int k=0;k<14 && same;++k)same=g.key[k]==key[k];
    if(!same) {++g.revision;for(int k=0;k<14;++k)g.key[k]=key[k];}
    if(!coherence || !same) {
      g.ax=boxRotate({1,0,0},d);g.ay=boxRotate({0,1,0},d);g.az=boxRotate({0,0,1},d);
      const float matrix[9]={g.ax.x,g.ay.x,g.az.x,g.ax.y,g.ay.y,g.az.y,g.ax.z,g.ay.z,g.az.z};
      for(int k=0;k<9;++k)g.matrix[k]=matrix[k];
      for(int k=0;k<3;++k)g.half[k]=cb.half[k];
      g.centre=rbAdd(rbV(d.position[0],d.position[1],d.position[2]),
          rbMat(g.matrix,rbV(cb.center[0],cb.center[1],cb.center[2])));
      const auto& ax=g.ax;const auto& ay=g.ay;const auto& az=g.az;const float* h=g.half;
      g.extent=rbV(fabsf(ax.x)*h[0]+fabsf(ay.x)*h[1]+fabsf(az.x)*h[2],
          fabsf(ax.y)*h[0]+fabsf(ay.y)*h[1]+fabsf(az.y)*h[2],
          fabsf(ax.z)*h[0]+fabsf(ay.z)*h[1]+fabsf(az.z)*h[2]);
      for(int c=0;c<8;++c)g.vertices[c]=rbAdd(g.centre,rbMat(g.matrix,
          rbV((c&1)?h[0]:-h[0],(c&2)?h[1]:-h[1],(c&4)?h[2]:-h[2])));
      g.box={g.centre,{rbMul(rbV(ax.x,ax.y,ax.z),h[0]),
          rbMul(rbV(ay.x,ay.y,ay.z),h[1]),rbMul(rbV(az.x,az.y,az.z),h[2])}};
      g.valid=true;
    }
    return g;
  };

  static std::vector<RbStep> steps;
  static std::vector<RbContact> contacts;
  static std::vector<short> stepOf;
  static std::vector<int> bodies;   // every physics object this frame
  steps.clear();
  contacts.clear();
  // Initial storage only: every reduced manifold is retained, including
  // dense stacks. Capacity grows and is reused across subsequent frames.
  if (contacts.capacity() < PHYS_MAX_CONTACTS) contacts.reserve(PHYS_MAX_CONTACTS);
  bodies.clear();
  // The physics objects, as indices. Walking every object in the scene to
  // find the few with data.physics set - reading two fields out of a
  // RuntimeObject far larger than a cache line each time - was 0.51 ms of a
  // frame with zero awake bodies in the dense Motor District scene, on a
  // physical PS2. data.physics is fixed per object, so the list only changes
  // when the scene or its object count does (spawns append).
  static std::vector<int> physObjIndex;
  static unsigned int physObjIndexGen = ~0u;
  static int physObjIndexCount = -1;
  if (physObjIndexGen != sceneGeneration || physObjIndexCount != count) {
    physObjIndex.clear();
    for (int i = 0; i < count; ++i)
      if (runtimeObjects[i].data.physics) physObjIndex.push_back(i);
    physObjIndexGen = sceneGeneration;
    physObjIndexCount = count;
  }

  unsigned predictionStart=CB::ticks();
  // --- 1. awake bodies: sync, integrate forces, predict the pose ------------
  for (int i : physObjIndex) {
    RuntimeObject& o = runtimeObjects[i];
    // Carried/thrown objects are driven by updateCarriedObject this frame.
    if (i == carryIndex || i == thrownIndex) continue;
    if (!o.active || !o.data.physics) continue;
    bodies.push_back(i);
  }
  if (bodies.empty()) return;
  if(useIslands) {
    // Wake every member of a previously sleeping component when any member
    // was pushed, scripted or otherwise woken. Never cull a collision here.
    static std::vector<unsigned char> wakeIsland;
    wakeIsland.assign(count,0);
    for(int i:bodies)if(!physAsleep(runtimeObjects[i]) && lastIsland[i]>=0)
      wakeIsland[lastIsland[i]]=1;
    for(int i:bodies)if(physAsleep(runtimeObjects[i]) && lastIsland[i]>=0 && wakeIsland[lastIsland[i]])
      runtimeObjects[i].restFrames=0;
  }
  bool anyAwake = false;
  for (int i : bodies)
    if (!physAsleep(runtimeObjects[i])) {
      anyAwake = true;
      break;
    }
  if (!anyAwake) return;  // a settled scene pays one pass over its bodies
  // No scene-sized collider allocation for empty or wholly sleeping scenes.
  if(worldGeometryGeneration!=sceneGeneration || worldGeometry.size()!=runtimeObjects.size()) {
    worldGeometry.clear();worldGeometry.resize(runtimeObjects.size());
    worldGeometryGeneration=sceneGeneration;
  }
  // physBodies may grow while slots are handed out - take every slot now,
  // before any reference into the vector is held.
  physBodies.reserve(physBodies.size() + bodies.size());
  for (int i : bodies) physBodyFor(i);
  stepOf.assign(count, -1);
  if(coherence) satGeometry.resize(bodies.size());

  auto makeStep = [&](int i, bool asleep) -> int {
    RuntimeObject& o = runtimeObjects[i];
    const int slot = physSlotOf[i];
    const PhysBody& b = physBodies[slot];
    RbStep s;
    s.obj = i;
    s.slot = slot;
    s.asleep = asleep;
    s.grounded = false;
    s.sphere = b.verts == 0;
    s.sphereR = b.radius;
    s.invMass = asleep ? 0.0F : b.invMass;
    s.bounce = o.data.physBounce;
    s.friction = o.data.physFriction;
    for (int k = 0; k < 4; ++k) s.q0[k] = b.q[k];
    rbQuatToMat(s.q0, s.R0);
    const RbV pos = rbV(o.data.position[0], o.data.position[1],
                        o.data.position[2]);
    s.x0 = rbAdd(pos, rbMat(s.R0, rbV(b.comL[0], b.comL[1], b.comL[2])));
    s.vp = s.wp = rbV(0.0F, 0.0F, 0.0F);
    if (asleep) {
      s.v = s.w = rbV(0.0F, 0.0F, 0.0F);
      s.x1 = s.x0;
      for (int k = 0; k < 9; ++k) s.R1[k] = s.R0[k], s.invIw[k] = 0.0F;
    } else {
      RbV v = rbV(o.velocityX, o.velocityY - gravityPerFrame, o.velocityZ);
      // Terminal fall velocity, 30 u/s real time (owner-tuned: 50 read as a
      // strobing blur in a door-sized infinite-fall loop, 15 as too floaty).
      const float termFall = 30.0F * g_frameDt;
      if (v.y < -termFall) v.y = -termFall;
      const float sp2 = rbDot(v, v);
      if (sp2 > PHYS_MAX_SPEED * PHYS_MAX_SPEED)
        v = rbMul(v, PHYS_MAX_SPEED / sqrtf(sp2));
      // A body that does not tumble never turns, whatever spin it was given.
      RbV w = b.tumble ? rbV(b.w[0], b.w[1], b.w[2]) : rbV(0.0F, 0.0F, 0.0F);
      const float w2 = rbDot(w, w);
      if (w2 > PHYS_MAX_SPIN * PHYS_MAX_SPIN)
        w = rbMul(w, PHYS_MAX_SPIN / sqrtf(w2));
      s.v = v;
      s.w = w;
      s.x1 = rbAdd(s.x0, v);
      float q1[4] = {s.q0[0], s.q0[1], s.q0[2], s.q0[3]};
      rbIntegrate(q1, w);
      rbQuatToMat(q1, s.R1);
      rbWorldInvI(s.R1, b.invI, s.invIw);
    }
    s.nv = b.verts;
    Tyra::collisionTransformPoints(s.R0, s.x0, b.lv, b.verts, s.wv0);
    if (asleep) {
      for (int k = 0; k < b.verts; ++k) s.wv[k] = s.wv0[k];
    } else Tyra::collisionTransformPoints(s.R1, s.x1, b.lv, b.verts, s.wv);
    if (s.sphere) {
      const RbV r = rbV(s.sphereR, s.sphereR, s.sphereR);
      s.bounds = {rbSub(s.x1, r), rbAdd(s.x1, r)};
      const RbV from = rbSub(s.x0, r), to = rbAdd(s.x0, r);
      s.bounds.mn = {std::min(s.bounds.mn.x, from.x),
                     std::min(s.bounds.mn.y, from.y), std::min(s.bounds.mn.z, from.z)};
      s.bounds.mx = {std::max(s.bounds.mx.x, to.x),
                     std::max(s.bounds.mx.y, to.y), std::max(s.bounds.mx.z, to.z)};
    } else {
      s.bounds = Tyra::convexMotionBounds(s.wv, s.nv, rbSub(s.x1, s.x0));
    }
    s.box = o.data.type == 0 && b.verts == 8;
    if (s.box) {
      float lo[3]={1e30F,1e30F,1e30F}, hi[3]={-1e30F,-1e30F,-1e30F};
      for (int v=0;v<b.verts;++v) for(int k=0;k<3;++k) {
        lo[k]=std::min(lo[k],b.lv[v*3+k]);hi[k]=std::max(hi[k],b.lv[v*3+k]);
      }
      s.obb.centre=rbAdd(s.x1,rbMat(s.R1,rbV((lo[0]+hi[0])*.5F,
          (lo[1]+hi[1])*.5F,(lo[2]+hi[2])*.5F)));
      for(int k=0;k<3;++k) s.obb.halfAxes[k]=rbMul(
          rbV(s.R1[k],s.R1[k+3],s.R1[k+6]),(hi[k]-lo[k])*.5F);
    }
    steps.push_back(s);
    if(coherence)satGeometry[steps.size()-1].valid=false;
    stepOf[i] = (short)(steps.size() - 1);
    return (int)steps.size() - 1;
  };
  steps.reserve(bodies.size());
  for (int i : bodies)
    if (!physAsleep(runtimeObjects[i])) makeStep(i, false);
  const int awakeCount = (int)steps.size(); CB::awake += awakeCount;

  auto transformedShape = [&](const RbStep& s,const PhysBody& b) -> SatGeometry& {
    auto& g=satGeometry[stepOf[s.obj]];
    if(!g.valid) {
      for(int k=0;k<b.planes;++k)g.normals[k]=rbMat(s.R1,rbV(b.lp[k*4],b.lp[k*4+1],b.lp[k*4+2]));
      for(int k=0;k<b.edges;++k)g.edges[k]=rbMat(s.R1,rbV(b.le[k*3],b.le[k*3+1],b.le[k*3+2]));
      g.valid=true;
    }
    return g;
  };

  auto satContact = [&](const RbStep& A, const PhysBody& Ba,
                         const RbV* bv, int bnv, const RbV* bn, int bnn,
                         const RbV* be, int bne, RbCand& result, RbV motionB,
                          const Tyra::CollisionObb* boxB = nullptr, int other = -1) {
    CB::StageScope satScope(5);
    if (!Tyra::collisionBoundsOverlap(A.bounds,
        Tyra::convexMotionBounds(bv, bnv, motionB))) return false;
    RbV normals[44], edges[66];
    for (int k = 0; !coherence && k < Ba.planes; ++k)
      normals[k] = rbMat(A.R1, rbV(Ba.lp[k*4], Ba.lp[k*4+1], Ba.lp[k*4+2]));
    for (int k = 0; !coherence && k < Ba.edges; ++k)
      edges[k] = rbMat(A.R1, rbV(Ba.le[k*3], Ba.le[k*3+1], Ba.le[k*3+2]));
    Tyra::ConvexContact c;
    const SatGeometry* geometry=coherence?&transformedShape(A,Ba):nullptr;
    const Tyra::ConvexView av = {A.wv,A.nv,geometry?geometry->normals:normals,
        Ba.planes,geometry?geometry->edges:edges,Ba.edges};
    const Tyra::ConvexView bvView = {bv,bnv,bn,bnn,be,bne};
    if (!Tyra::convexMotionContact(av, bvView, rbSub(A.x1, A.x0), motionB, c,
        A.box ? &A.obb : nullptr, boxB,
        coherence?&axisHistory.acquire(A.obj,other):nullptr))
      return false;
    result.n = c.normal; result.p = c.point; result.depth = c.depth;
    return true;
  };
  RbCand cand[48];
  RbCand red[4];
  auto emit = [&](int a, int b, const RbCand* cs, int n, int worldObject=-1) {
    const int m = rbReduce(cs, n, red); CB::generated += m;
    for (int k = 0; k < m; ++k) {
      RbContact c;
      c.other=b>=0?steps[b].obj:worldObject;c.history=-1;
      c.a = (short)a;
      c.b = (short)b;
      c.n = red[k].n;
      c.p = red[k].p;
      c.depth = red[k].depth;
      CB::maxDepth=std::max(CB::maxDepth,c.depth);
      contacts.push_back(c);
    }
  };

  CB::stageTicks[0]+=CB::ticks()-predictionStart;
  { CB::StageScope phaseScope(1);
  // --- 2. contacts against the world ----------------------------------------
  for (int si = 0; si < awakeCount; ++si) {
    RbStep& S = steps[si];
    RuntimeObject& o = runtimeObjects[S.obj];
    const PhysBody& B = physBodies[S.slot];
    const RbV x1 = S.x1;

    // Terrain. Floor-portal swallowing: a body over a linked, object-
    // teleporting floor portal ignores the terrain (see portalSwallowZone),
    // swept rather than point-sampled so a terminal-velocity faller cannot
    // step over the approach zone and land on the ground above the portal.
    bool swallowed = false;
    {
      const Vec4 a4(S.x0.x, S.x0.y, S.x0.z, 1.0F), b4(x1.x, x1.y, x1.z, 1.0F);
      for (int pi = 0; PORTAL_COUNT > 0 && pi < PORTAL_COUNT; ++pi) {
        const PortalData& p = PORTALS[pi];
        if (p.scene != currentScene || p.object < 0 || p.target < 0) continue;
        if (!portalCanCross(p, S.obj)) continue;
        if (p.object >= count || p.target >= count) continue;
        RuntimeObject& m = runtimeObjects[p.object];
        if (!m.active || !m.visible || !runtimeObjects[p.target].active) continue;
        if (&o == &m || &o == &runtimeObjects[p.target]) continue;
        if (portalSwallowSwept(m, 0.5F * m.data.scale[0] + 0.25F,
                               0.5F * m.data.scale[1] + 0.25F, a4, b4)) {
          swallowed = true;
          break;
        }
      }
    }
    const float hC = terrainHeightAt(x1.x, x1.z);
    if (!swallowed && x1.y - B.radius < hC + B.radius + 0.1F) {
      const float hs = 0.35F;
      RbV nT = rbV(terrainHeightAt(x1.x - hs, x1.z) - terrainHeightAt(x1.x + hs, x1.z),
                   2.0F * hs,
                   terrainHeightAt(x1.x, x1.z - hs) - terrainHeightAt(x1.x, x1.z + hs));
      nT = rbMul(nT, 1.0F / sqrtf(rbDot(nT, nT)));
      int n = 0;
      if (S.sphere) {
        const RbV bottom = rbSub(x1, rbMul(nT, S.sphereR));
        const float h = terrainHeightAt(bottom.x, bottom.z);
        if (bottom.y < h) {
          cand[n].n = nT;
          cand[n].p = bottom;
          cand[n].depth = (h - bottom.y) * nT.y;
          ++n;
        }
      } else {
        for (int k = 0; k < S.nv && n < 48; ++k) {
          const RbV p = S.wv[k];
          const float h = terrainHeightAt(p.x, p.z);
          if (p.y >= h) continue;
          cand[n].n = nT;
          cand[n].p = p;
          cand[n].depth = (h - p.y) * nT.y;
          ++n;
        }
      }
      if (n) emit(si, -1, cand, n);
    }

    // Aiming into a linked opening this frame: solids the opening is cut
    // into stop blocking this body (the walkers' doorway rule, shared through
    // portalDoorwayOpens). The segment is padded by the body's extent, since
    // the contacts stop its centre ~r short of a wall at the plane.
    float aimPlane[4] = {0, 0, 0, 0};
    float aimPoint[3] = {0, 0, 0};
    bool aimOn = false;
    if (PORTAL_COUNT > 0) {
      const float a3[3] = {S.x0.x, S.x0.y, S.x0.z};
      const RbV mv = rbSub(x1, S.x0);
      const float mvLen = sqrtf(rbDot(mv, mv));
      const float pad = mvLen > 1e-6F ? 1.0F + (B.radius + 0.1F) / mvLen : 1.0F;
      const float b3[3] = {S.x0.x + mv.x * pad, S.x0.y + mv.y * pad,
                           S.x0.z + mv.z * pad};
      const int aim = portalCarryAim(a3, b3, S.obj);
      if (aim >= 0) {
        const RuntimeObject& pm = runtimeObjects[PORTALS[aim].object];
        const V3 pn = rotated({0.0F, 0.0F, 1.0F}, pm.data.rotation);
        aimPlane[0] = pn.x, aimPlane[1] = pn.y, aimPlane[2] = pn.z;
        aimPlane[3] = pn.x * pm.data.position[0] + pn.y * pm.data.position[1] +
                      pn.z * pm.data.position[2];
        for (int k = 0; k < 3; ++k) aimPoint[k] = portalAimPoint[k];
        aimOn = true;
      }
    }

    const float reach = B.radius + sqrtf(rbDot(S.v, S.v)) + 0.05F;
    // Broad phase: the candidates within the body's reach (in 3D); then a
    // centre + reject radius from the collision box, no trigonometry.
    {
      Tyra::BroadBox area;
      area.mn[0] = x1.x - reach;
      area.mn[1] = x1.y - reach;
      area.mn[2] = x1.z - reach;
      area.mx[0] = x1.x + reach;
      area.mx[1] = x1.y + reach;
      area.mx[2] = x1.z + reach;
      {CB::StageScope q(4);broadPhaseNear(area,bpNearPhys);}
    }
    for (int j : bpNearPhys) {
      if (j == S.obj) continue;
      RuntimeObject& s = runtimeObjects[j];
      if (!s.active || s.data.physics || !physObstacle(s.data)) continue;
      const CollisionBox scb = objectCollisionBox(s);
      WorldGeometry& staticShape=worldShape(j,scb);
      const float sc2 = scb.center[0] * scb.center[0] +
                        scb.center[1] * scb.center[1] +
                        scb.center[2] * scb.center[2];
      const float sh2 = scb.half[0] * scb.half[0] + scb.half[1] * scb.half[1] +
                        scb.half[2] * scb.half[2];
      const float dx = s.data.position[0] - x1.x, dy = s.data.position[1] - x1.y,
                  dz = s.data.position[2] - x1.z;
      const float rr = sqrtf(sc2) + sqrtf(sh2) + reach;
      if (dx * dx + dy * dy + dz * dz > rr * rr) continue;
      const GameModel* sgm = nullptr;
      if (s.data.type == 5 && s.data.model >= 0 &&
          s.data.model < (int)gameModels.size())
        sgm = &gameModels[s.data.model];
      int n = 0;

      // --- a collision-mesh model: its TRIANGLES, not its box -------------
      // A merged building's box encloses its own rooms, so a body inside it
      // (thrown through a portal into a cellar, rolled in through a door)
      // must meet the floors and walls, not be ejected from the box. Every
      // hull corner casts its own path this frame - from where it was, a
      // skin behind, to where it is predicted - so a fast corner cannot cross
      // a thin floor between two frames and a stool finds all four feet.
      if (s.data.collision == 1 && sgm && !sgm->collider.empty()) {
        float Rs[9];
        rbEulerToMat(s.data.rotation, Rs);
        float sc[3];
        for (int k = 0; k < 3; ++k)
          sc[k] = fabsf(s.data.scale[k]) > 0.0001F ? s.data.scale[k] : 0.0001F;
        const RbV sp = rbV(s.data.position[0], s.data.position[1],
                           s.data.position[2]);
        auto toLocal = [&](RbV w) {
          const RbV l = rbMatT(Rs, rbSub(w, sp));
          return rbV(l.x / sc[0], l.y / sc[1], l.z / sc[2]);
        };
        auto dirLocal = [&](RbV w) {
          const RbV l = rbMatT(Rs, w);
          return rbV(l.x / sc[0], l.y / sc[1], l.z / sc[2]);
        };
        const float* mn = sgm->collider.aabbMin();
        const float* mx = sgm->collider.aabbMax();
        const int nPts = S.sphere ? 1 : S.nv;
        for (int k = 0; k < nPts && n < 48; ++k) {
          RbV p0, p1;
          if (S.sphere) {  // the lowest point of the ball, along gravity
            p0 = rbSub(S.x0, rbV(0.0F, S.sphereR, 0.0F));
            p1 = rbSub(x1, rbV(0.0F, S.sphereR, 0.0F));
          } else {
            p0 = S.wv0[k];
            p1 = S.wv[k];
          }
          const RbV seg = rbSub(p1, p0);
          const float L = sqrtf(rbDot(seg, seg));
          const RbV dir = L > 1e-5F ? rbMul(seg, 1.0F / L) : rbV(0.0F, -1.0F, 0.0F);
          const float skin = 0.05F;
          const RbV org = rbSub(p0, rbMul(dir, skin));
          const RbV ol = toLocal(org);
          RbV dl = dirLocal(rbMul(dir, L + skin));
          const float ll = sqrtf(rbDot(dl, dl));
          if (ll < 1e-7F) continue;
          const RbV el = rbAdd(ol, dl);
          if ((ol.x < mn[0] && el.x < mn[0]) || (ol.x > mx[0] && el.x > mx[0]) ||
              (ol.y < mn[1] && el.y < mn[1]) || (ol.y > mx[1] && el.y > mx[1]) ||
              (ol.z < mn[2] && el.z < mn[2]) || (ol.z > mx[2] && el.z > mx[2]))
            continue;
          dl = rbMul(dl, 1.0F / ll);
          float t, nl[3];
          if (!sgm->collider.raycast(Vec4(ol.x, ol.y, ol.z, 1.0F),
                                     Vec4(dl.x, dl.y, dl.z, 0.0F), ll, &t, nl))
            continue;
          const RbV hitL = rbAdd(ol, rbMul(dl, t));
          const RbV hitW = rbAdd(sp, rbMat(Rs, rbV(hitL.x * sc[0], hitL.y * sc[1],
                                                   hitL.z * sc[2])));
          RbV nw = rbMat(Rs, rbV(nl[0] / sc[0], nl[1] / sc[1], nl[2] / sc[2]));
          nw = rbMul(nw, 1.0F / sqrtf(rbDot(nw, nw)));
          if (rbDot(nw, dir) > 0.0F) nw = rbMul(nw, -1.0F);
          const float depth = rbDot(rbSub(hitW, p1), nw);
          if (depth <= 0.0F) continue;
          cand[n].n = nw;
          cand[n].p = p1;
          cand[n].depth = depth;
          ++n;
        }
        if (S.sphere && n < 48) {
          const RbV from = toLocal(S.x0), to = toLocal(S.x1);
          float fraction, localNormal[3];
          const float scaleMin=std::min(fabsf(sc[0]),std::min(fabsf(sc[1]),fabsf(sc[2])));
          if(sgm->collider.sweepSphere(Vec4(from.x,from.y,from.z,1),
              Vec4(to.x,to.y,to.z,1),S.sphereR/scaleMin,&fraction,localNormal)) {
            RbV normal=rbMat(Rs,rbV(localNormal[0]/sc[0],localNormal[1]/sc[1],localNormal[2]/sc[2]));
            normal=rbMul(normal,1.0F/sqrtf(rbDot(normal,normal)));
            const RbV hit=rbAdd(S.x0,rbMul(rbSub(S.x1,S.x0),fraction));
            cand[n].n=normal; cand[n].p=rbSub(hit,rbMul(normal,S.sphereR));
            cand[n].depth=std::max(0.0F,rbDot(rbSub(hit,S.x1),normal)); ++n;
          }
          // The ball's sides: its sphere out of steep faces, side-aware.
          const RbV up = dirLocal(rbV(0.0F, 1.0F, 0.0F));
          const float ul = sqrtf(rbDot(up, up));
          const RbV lc = toLocal(x1), lp0 = toLocal(S.x0);
          Vec4 center(lc.x, lc.y, lc.z, 1.0F);
          const Vec4 prevLocal(lp0.x, lp0.y, lp0.z, 1.0F);
          const float sAvg = (sc[0] + sc[2]) * 0.5F;
          if (n < 48 && sgm->collider.resolveSphere(&center, S.sphereR / sAvg, 0.7F,
                                          Vec4(up.x / ul, up.y / ul, up.z / ul, 0.0F),
                                          &prevLocal)) {
            const RbV w = rbAdd(sp, rbMat(Rs, rbV(center.x * sc[0], center.y * sc[1],
                                                  center.z * sc[2])));
            const RbV push = rbSub(w, x1);
            const float pl = sqrtf(rbDot(push, push));
            if (pl > 1e-6F) {
              cand[n].n = rbMul(push, 1.0F / pl);
              cand[n].p = rbSub(x1, rbMul(cand[n].n, S.sphereR));
              cand[n].depth = pl;
              ++n;
            }
          }
        }
        if (n) emit(si, -1, cand, n, j);
        continue;
      }

      // --- a box collider: the object's collision box, rotation included ---
      // The walkers' doorway rule: a WALL portal opens the geometry's walls
      // only (its floor keeps carrying the body), a FLOOR portal opens it all.
      const bool doorway = aimOn && portalDoorwayOpens(s, aimPlane, aimPoint);
      if (doorway && fabsf(aimPlane[1]) >= 0.5F) continue;
      const V3& ax=staticShape.ax;const V3& ay=staticShape.ay;const V3& az=staticShape.az;
      const float* Bm=staticShape.matrix;const float* h=staticShape.half;
      const RbV bc=staticShape.centre,wh=staticShape.extent;
      if (!Tyra::collisionBoundsOverlap(S.bounds,
          {rbSub(bc, wh), rbAdd(bc, wh)})) continue;
      if (S.sphere) {
        const RbV l=rbMatT(Bm,rbSub(x1,bc));
        const float lc[3]={l.x,l.y,l.z};float cl[3];bool inside=true;
        for(int k=0;k<3;++k){cl[k]=std::max(-h[k],std::min(h[k],lc[k]));inside &= cl[k]==lc[k];}
        RbV normal;float depth=0;
        if(inside){int axis=0;float pen=1e30F;
          for(int k=0;k<3;++k){float d=h[k]-fabsf(lc[k]);if(d<pen){pen=d;axis=k;}}
          float v[3]={0,0,0};v[axis]=lc[axis]<0?-1.0F:1.0F;
          normal=rbV(v[0],v[1],v[2]);depth=pen+S.sphereR;
        }else{
          const RbV delta=rbV(lc[0]-cl[0],lc[1]-cl[1],lc[2]-cl[2]);
          const float distance=sqrtf(rbDot(delta,delta));
          if(distance<S.sphereR){normal=rbMul(delta,1.0F/distance);depth=S.sphereR-distance;}
        }
        if(depth>0){cand[0].n=rbMat(Bm,normal);cand[0].p=rbSub(x1,rbMul(cand[0].n,S.sphereR));cand[0].depth=depth;n=1;}
      } else {
        // Hull corners inside the box, pushed out through the face they
        // came in by (side-aware - a thin wall must not eject a fast corner
        // out of its far side), else the nearest face.
        for (int k = 0; k < S.nv && n < 48; ++k) {
          const RbV l = rbMatT(Bm, rbSub(S.wv[k], bc));
          const float lc[3] = {l.x, l.y, l.z};
          if (fabsf(lc[0]) >= h[0] || fabsf(lc[1]) >= h[1] || fabsf(lc[2]) >= h[2])
            continue;
          const RbV l0 = rbMatT(Bm, rbSub(S.wv0[k], bc));
          const float lc0[3] = {l0.x, l0.y, l0.z};
          int ak = -1;
          float out = 0.0F;
          for (int a = 0; a < 3; ++a) {
            const float e = fabsf(lc0[a]) - h[a];
            if (e > out) out = e, ak = a;
          }
          float sgn, depth;
          if (ak >= 0) {
            sgn = lc0[ak] < 0.0F ? -1.0F : 1.0F;
            depth = h[ak] - sgn * lc[ak];
          } else {
            float pen = 1e30F;
            for (int a = 0; a < 3; ++a) {
              const float pk = h[a] - fabsf(lc[a]);
              if (pk < pen) pen = pk, ak = a;
            }
            sgn = lc[ak] < 0.0F ? -1.0F : 1.0F;
            depth = pen;
          }
          float nv3[3] = {0.0F, 0.0F, 0.0F};
          nv3[ak] = sgn;
          cand[n].n = rbMat(Bm, rbV(nv3[0], nv3[1], nv3[2]));
          cand[n].p = S.wv[k];
          cand[n].depth = depth;
          ++n;
        }
        // Box corners inside the hull: a body lying across a narrow beam or
        // a kerb edge rests on the edge, which no hull corner touches.
        for (int c = 0; c < 8 && n < 48; ++c) {
          const RbV cl = rbV((c & 1) ? h[0] : -h[0], (c & 2) ? h[1] : -h[1],
                             (c & 4) ? h[2] : -h[2]);
          const RbV cw = rbAdd(bc, rbMat(Bm, cl));
          const RbV rel = rbSub(cw, x1);
          if (rbDot(rel, rel) > B.radius * B.radius) continue;
          const RbV lc = rbMatT(S.R1, rel);
          float depth;
          const int f = rbInsideHull(B.lp, B.planes, lc, &depth);
          if (f < 0) continue;
          const float* pl = B.lp + f * 4;
          cand[n].n = rbMul(rbMat(S.R1, rbV(pl[0], pl[1], pl[2])), -1.0F);
          cand[n].p = cw;
          cand[n].depth = depth;
          ++n;
        }
      }
      if (!n && S.sphere) {
        const RbV p0 = rbMatT(Bm,rbSub(S.x0,bc)), p1 = rbMatT(Bm,rbSub(S.x1,bc));
        const float from[3]={p0.x,p0.y,p0.z}, to[3]={p1.x,p1.y,p1.z};
        const float mn[3]={-h[0]-S.sphereR,-h[1]-S.sphereR,-h[2]-S.sphereR};
        const float mx[3]={h[0]+S.sphereR,h[1]+S.sphereR,h[2]+S.sphereR};
        float t,sign;int axis;
        if(Tyra::collisionSweepBox(from,to,mn,mx,3,t,axis,sign)) {
          float normal[3]={0,0,0};normal[axis]=sign;
          cand[0].n=rbMat(Bm,rbV(normal[0],normal[1],normal[2]));
          cand[0].p=rbSub(rbAdd(S.x0,rbMul(rbSub(S.x1,S.x0),t)),rbMul(cand[0].n,S.sphereR));
          cand[0].depth=std::max(0.0F,(sign>0?mx[axis]-to[axis]:to[axis]-mn[axis])); n=1;
        }
      }
      if (!n && !S.sphere) {
        const RbV axes[3]={{ax.x,ax.y,ax.z},{ay.x,ay.y,ay.z},{az.x,az.y,az.z}};
        if (satContact(S,B,staticShape.vertices,8,axes,3,axes,3,cand[0],
            rbV(0,0,0),&staticShape.box,j)) n = 1;
      }
      if (doorway) {  // through a wall portal only the floor answers
        int m = 0;
        for (int k = 0; k < n; ++k)
          if (cand[k].n.y > 0.7F) cand[m++] = cand[k];
        n = m;
      }
      if (n) emit(si, -1, cand, n, j);
    }
  }

  }
  { CB::StageScope phaseScope(2);
  // --- 3. contacts between bodies -------------------------------------------
  // A sleeping partner is immovable this frame; a hit hard enough wakes it
  // for the next one, and so does its support sliding out from under it.
  // Index predicted body bounds once, rather than scanning every body per
  // awake body. Sleeping COMs use their orientation, not the object origin.
  static Tyra::BroadPhase bodyPairs;
  static std::vector<int> nearBodies;
  struct LocalBoundsCache {bool valid=false;unsigned revision=0;Tyra::CollisionBounds bounds;};
  static std::vector<LocalBoundsCache> localBoundsCache;
  static unsigned localBoundsGeneration=~0u;
  if(coherence && (localBoundsGeneration!=sceneGeneration || localBoundsCache.size()!=runtimeObjects.size())) {
    localBoundsCache.clear();localBoundsCache.resize(runtimeObjects.size());localBoundsGeneration=sceneGeneration;
  }
  unsigned bodyGridStart=CB::ticks();
  bodyPairs.begin((int)bodies.size());
  for (size_t pairIndex=0; pairIndex<bodies.size(); ++pairIndex) {
    const int j=bodies[pairIndex];
    const PhysBody& B = physBodies[physSlotOf[j]];
    RbV c, previous;Tyra::CollisionBounds tight{};
    if (stepOf[j] >= 0) {
      c=steps[stepOf[j]].x1;previous=steps[stepOf[j]].x0;
      if(coherence)tight=steps[stepOf[j]].bounds;
    }
    else {
      float R[9];
      rbQuatToMat(B.q, R);
      const auto& o = runtimeObjects[j];
      c = rbAdd(rbV(o.data.position[0], o.data.position[1], o.data.position[2]),
                rbMat(R, rbV(B.comL[0], B.comL[1], B.comL[2])));
      previous = c;
      if(coherence) {
        if(!B.verts) {
          const RbV r=rbV(B.radius,B.radius,B.radius);tight={rbSub(c,r),rbAdd(c,r)};
        } else {
          auto& cached=localBoundsCache[j];
          if(!cached.valid || cached.revision!=rbRevisions[j]) {
            cached.bounds={{1e30F,1e30F,1e30F},{-1e30F,-1e30F,-1e30F}};
            for(int k=0;k<B.verts;++k) {
              const float* v=B.lv+k*3;
              cached.bounds.mn.x=std::min(cached.bounds.mn.x,v[0]);cached.bounds.mx.x=std::max(cached.bounds.mx.x,v[0]);
              cached.bounds.mn.y=std::min(cached.bounds.mn.y,v[1]);cached.bounds.mx.y=std::max(cached.bounds.mx.y,v[1]);
              cached.bounds.mn.z=std::min(cached.bounds.mn.z,v[2]);cached.bounds.mx.z=std::max(cached.bounds.mx.z,v[2]);
            }
            cached.revision=rbRevisions[j];cached.valid=true;
          }
          tight=Tyra::collisionTransformBounds(cached.bounds,R,c);
        }
      }
    }
    Tyra::BroadBox box;
    const float v[3] = {c.x, c.y, c.z}, prev[3] = {previous.x,previous.y,previous.z};
    if(coherence) {
      const float lo[3]={tight.mn.x,tight.mn.y,tight.mn.z},hi[3]={tight.mx.x,tight.mx.y,tight.mx.z};
      for(int k=0;k<3;++k){box.mn[k]=lo[k]-1e-4F;box.mx[k]=hi[k]+1e-4F;}
    } else for (int k = 0; k < 3; ++k) {
      box.mn[k] = std::min(v[k],prev[k]) - B.radius;
      box.mx[k] = std::max(v[k],prev[k]) + B.radius;
    }
    bodyPairs.set((int)pairIndex, box, false);
  }
  bodyPairs.commit();
  CB::stageTicks[3]+=CB::ticks()-bodyGridStart;
  for (int si = 0; si < awakeCount; ++si) {
    const int i = steps[si].obj;
    if (!physObstacle(runtimeObjects[i].data)) continue;
    Tyra::BroadBox pairArea;
    const RbStep& queryStep = steps[si];
    const float queryRadius = physBodies[queryStep.slot].radius;
    const float queryCentre[3] = {queryStep.x1.x, queryStep.x1.y, queryStep.x1.z};
    const float queryPrev[3] = {queryStep.x0.x,queryStep.x0.y,queryStep.x0.z};
    if(coherence) {
      const auto& bounds=queryStep.bounds;
      const float lo[3]={bounds.mn.x,bounds.mn.y,bounds.mn.z},hi[3]={bounds.mx.x,bounds.mx.y,bounds.mx.z};
      for(int k=0;k<3;++k){pairArea.mn[k]=lo[k]-1e-4F;pairArea.mx[k]=hi[k]+1e-4F;}
    } else for (int k = 0; k < 3; ++k) {
      pairArea.mn[k] = std::min(queryCentre[k],queryPrev[k]) - queryRadius;
      pairArea.mx[k] = std::max(queryCentre[k],queryPrev[k]) + queryRadius;
    }
    {CB::StageScope q(4);bodyPairs.queryBox(pairArea,nearBodies);} CB::bodyCandidates+=nearBodies.size();
    for (int candidate : nearBodies) {
      const int j=bodies[(size_t)candidate];
      if (j == i) continue;
      RuntimeObject& ob = runtimeObjects[j];
      if (!physObstacle(ob.data)) continue;
      // Asleep = has no step of its own this frame (a sleeper woken earlier
      // in this loop is still immovable until the next frame).
      const bool jAsleep = stepOf[j] < 0 || steps[stepOf[j]].asleep;
      if (!jAsleep && j < i) continue;  // an awake pair is visited once
      const PhysBody& Bj = physBodies[physSlotOf[j]];
      int sj = stepOf[j];
      if (sj < 0) sj = makeStep(j, true);
      const RbStep& A = steps[si];
      const RbStep& Bs = steps[sj];
      const PhysBody& Ba = physBodies[A.slot];
      // The grid's swept sphere bounds deliberately over-select. Reject by
      // cached hull/sphere envelopes before vertex planes, SAT or CCD. This
      // is conservative for every contact path below, including linear TOI.
      if (!Tyra::collisionBoundsOverlap(A.bounds, Bs.bounds)) {++CB::bodyBoundsRejects;continue;}
      const RbV d = rbSub(A.x1, Bs.x1);
      const float d2 = rbDot(d, d);
      int n = 0;
      if (A.sphere && Bs.sphere) {
        const float dl = sqrtf(d2 > 1e-10F ? d2 : 1e-10F);
        const float pen = A.sphereR + Bs.sphereR - dl;
        if (pen > 0.0F) {
          cand[0].n = d2 > 1e-10F ? rbMul(d, 1.0F / dl) : rbV(0.0F, 1.0F, 0.0F);
          cand[0].p = rbSub(A.x1, rbMul(cand[0].n, A.sphereR));
          cand[0].depth = pen;
          n = 1;
        }
      } else if (A.sphere || Bs.sphere) {
        // sphere against hull: the face of largest separation decides
        const RbStep& Hs = A.sphere ? Bs : A;
        const RbStep& Ss = A.sphere ? A : Bs;
        const PhysBody& Hb = physBodies[Hs.slot];
        const RbV lc = rbMatT(Hs.R1, rbSub(Ss.x1, Hs.x1));
        Tyra::ConvexContact contact;
        if (Tyra::sphereConvexContact(lc,Ss.sphereR,Hb.lv,Hb.verts,Hb.lp,Hb.planes,contact)) {
          const RbV nw = rbMat(Hs.R1, contact.normal);
          cand[0].p = rbAdd(Hs.x1, rbMat(Hs.R1, contact.point));
          cand[0].depth = contact.depth;
          cand[0].n = A.sphere ? nw : rbMul(nw, -1.0F); n = 1;
        }
      } else {
        // hull against hull: each one's corners inside the other
        for (int k = 0; k < A.nv && n < 48; ++k) {
          const RbV rel = rbSub(A.wv[k], Bs.x1);
          if (rbDot(rel, rel) > Bj.radius * Bj.radius) continue;
          float depth;
          const int f = rbInsideHull(Bj.lp, Bj.planes, rbMatT(Bs.R1, rel), &depth);
          if (f < 0) continue;
          const float* pl = Bj.lp + f * 4;
          cand[n].n = rbMat(Bs.R1, rbV(pl[0], pl[1], pl[2]));
          cand[n].p = A.wv[k];
          cand[n].depth = depth;
          ++n;
        }
        for (int k = 0; k < Bs.nv && n < 48; ++k) {
          const RbV rel = rbSub(Bs.wv[k], A.x1);
          if (rbDot(rel, rel) > Ba.radius * Ba.radius) continue;
          float depth;
          const int f = rbInsideHull(Ba.lp, Ba.planes, rbMatT(A.R1, rel), &depth);
          if (f < 0) continue;
          const float* pl = Ba.lp + f * 4;
          cand[n].n = rbMul(rbMat(A.R1, rbV(pl[0], pl[1], pl[2])), -1.0F);
          cand[n].p = Bs.wv[k];
          cand[n].depth = depth;
          ++n;
        }
      }
      if (!n && A.sphere && Bs.sphere) {
        Tyra::ConvexContact c;
        if (Tyra::sphereSweepContact(A.x0,A.x1,A.sphereR,Bs.x0,Bs.x1,Bs.sphereR,c)) {
          cand[0].n=c.normal; cand[0].p=c.point; cand[0].depth=c.depth; n=1;
        }
      }
      if (!n && !A.sphere && !Bs.sphere) {
        RbV normals[44], edges[66];
        for (int k=0; !coherence && k<Bj.planes; ++k)
          normals[k]=rbMat(Bs.R1,rbV(Bj.lp[k*4],Bj.lp[k*4+1],Bj.lp[k*4+2]));
        for (int k=0; !coherence && k<Bj.edges; ++k)
          edges[k]=rbMat(Bs.R1,rbV(Bj.le[k*3],Bj.le[k*3+1],Bj.le[k*3+2]));
        const SatGeometry* geometry=coherence?&transformedShape(Bs,Bj):nullptr;
        if(satContact(A,Ba,Bs.wv,Bs.nv,geometry?geometry->normals:normals,Bj.planes,
            geometry?geometry->edges:edges,Bj.edges,cand[0],rbSub(Bs.x1,Bs.x0),
            Bs.box?&Bs.obb:nullptr,Bs.obj)) n=1;
      }
      if (!n) continue;
      if (Bs.asleep) {
        // Wake the sleeper on a real hit, or when it rides on this body and
        // this body is moving out from under it.
        bool wake = false;
        for (int k = 0; k < n && !wake; ++k) {
          const RbV ra = rbSub(cand[k].p, A.x1);
          const float vn = rbDot(rbAdd(A.v, rbCross(A.w, ra)), cand[k].n);
          if (-vn > wakeSpeed) wake = true;
          if (cand[k].n.y < -0.5F && A.v.x * A.v.x + A.v.z * A.v.z > PHYS_REST_SPEED2)
            wake = true;
        }
        if (wake) ob.restFrames = 0;
      }
      emit(si, sj, cand, n);
    }
  }

  }
  { CB::SolverScope solverScope;
  // --- 4. sequential impulses (prepared backend is opt-in) ------------------
  // Independent dynamic components: static/world partners never join them.
  if(useIslands) {
    islands.begin(awakeCount);
    for(const auto& c:contacts)
      if(c.b>=0 && !steps[c.b].asleep)islands.link(c.a,c.b);
    islands.arrange(contacts);
    static std::vector<RbContact> orderedContacts;
    orderedContacts.resize(contacts.size());
    for(size_t k=0;k<contacts.size();++k)orderedContacts[k]=contacts[islands.order[k]];
    contacts.swap(orderedContacts);
    for(int si=0;si<awakeCount;++si)lastIsland[steps[si].obj]=steps[islands.root(si)].obj;
  }
  auto restoreContact = [&](RbContact& c) {
    if(!warmStart)return;
    const auto& a=steps[c.a];
    const auto* b=c.b>=0?&steps[c.b]:nullptr;
    const unsigned revB=b?rbRevisions[b->obj]:
        c.other>=0?worldGeometry[c.other].revision:0;
    const RbV anchorA=rbMatT(a.R1,rbSub(c.p,a.x1));
    const RbV anchorB=b?rbMatT(b->R1,rbSub(c.p,b->x1)):c.p;
    Tyra::ContactMemory memory{a.obj,c.other,rbRevisions[a.obj],revB,
        unsigned(a.asleep)|(b && b->asleep?2u:0u),anchorA,anchorB,c.n,{},0};
    c.history=contactHistory.add(memory,c.bounceTarget==0 && c.vnPred<=bounceThreshold);
    const auto& old=contactHistory[c.history];c.jn=old.normalImpulse;c.ft=old.friction;
    const float limit=c.mu*c.jn,l2=rbDot(c.ft,c.ft);
    if(l2>limit*limit)c.ft=rbMul(c.ft,limit/sqrtf(l2));
  };

  const int nc = (int)contacts.size(); CB::contacts += nc;
#if TYRA_PHYSICS_PREPARED
  static Tyra::SolverBuffer<Tyra::SolverBody> solverBodies;
  static Tyra::SolverBuffer<Tyra::SolverContact> solverContacts;
  if (nc > 0) {
    solverBodies.resize(steps.size()+1);
    solverContacts.resize(contacts.size());
    for (size_t i=0;i<steps.size();++i) {
      const RbStep& s=steps[i];auto& d=solverBodies[i];
      d.v=Tyra::sv(s.v,s.invMass);d.w=Tyra::sv(s.w);
      d.vp=Tyra::sv(s.vp);d.wp=Tyra::sv(s.wp);
      for(int k=0;k<3;++k)d.invI[k]={s.invIw[k],s.invIw[k+3],s.invIw[k+6],0};
    }
    solverBodies.back()=Tyra::SolverBody{};
    for(int k=0;k<nc;++k) {
      RbContact& c=contacts[k];auto& d=solverContacts[k];
      RbStep& a=steps[c.a];d.friction.a=c.a;d.friction.b=c.b>=0?c.b:(int)steps.size();
      d.normal=Tyra::sv(c.n);d.ra=Tyra::sv(rbSub(c.p,a.x1));
      d.rb=Tyra::sv(c.b>=0?rbSub(c.p,steps[c.b].x1):rbV(0,0,0),c.depth);
      float e=a.bounce,f=a.friction;
      if(c.b>=0) {
        const RbStep& b=steps[c.b];e=std::max(e,b.bounce);f=.5F*(f+b.friction);
        if(c.n.y<-.5F)steps[c.b].grounded=true;
      }
      if(c.n.y>.5F)a.grounded=true;
      Tyra::prepareSolverContact(d,solverBodies[d.friction.a],solverBodies[d.friction.b],e,f,bounceThreshold);
      c.jn=0;c.ft=rbV(0,0,0);c.mu=d.angularB.w;c.vnPred=d.ra.w;c.bounceTarget=d.normal.w;
      restoreContact(c);d.k[0].w=c.jn;
      d.friction.x=c.ft.x;d.friction.y=c.ft.y;d.friction.z=c.ft.z;
    }
    if(warmStart)for(int k=0;k<nc;++k) {
      auto& c=solverContacts[k];
      const auto p=Tyra::sv(rbAdd(rbMul(Tyra::xyz(c.normal),c.k[0].w),Tyra::xyz(c.friction)));
      Tyra::solverImpulse<false>(solverBodies[c.friction.a],solverBodies[c.friction.b],c,p);
    }
    Tyra::solvePhysics(solverBodies.data(),solverContacts.data(),nc,
        PHYS_ITERATIONS,PHYS_POS_ITERATIONS,PHYS_SLOP,PHYS_BAUMGARTE,
        TYRA_PHYSICS_SOLVER_VU0 != 0);
    if(warmStart)for(int k=0;k<nc;++k) {
      contacts[k].jn=solverContacts[k].k[0].w;contacts[k].ft=Tyra::xyz(solverContacts[k].friction);
    }
    for(size_t i=0;i<steps.size();++i) {
      auto& d=steps[i];const auto& s=solverBodies[i];
      d.v=Tyra::xyz(s.v);d.w=Tyra::xyz(s.w);
      d.vp=Tyra::xyz(s.vp);d.wp=Tyra::xyz(s.wp);
    }
  }
#else
  for (int k = 0; k < nc; ++k) {
    RbContact& c = contacts[k];
    RbStep& A = steps[c.a];
    c.ra = rbSub(c.p, A.x1);
    RbV vrel = rbAdd(A.v, rbCross(A.w, c.ra));
    const RbV ca = rbCross(c.ra, c.n);
    float kn = A.invMass + rbDot(rbCross(rbMat(A.invIw, ca), c.ra), c.n);
    float e = A.bounce, f = A.friction;
    if (c.b >= 0) {
      RbStep& Bs = steps[c.b];
      c.rb = rbSub(c.p, Bs.x1);
      vrel = rbSub(vrel, rbAdd(Bs.v, rbCross(Bs.w, c.rb)));
      const RbV cb = rbCross(c.rb, c.n);
      kn += Bs.invMass + rbDot(rbCross(rbMat(Bs.invIw, cb), c.rb), c.n);
      if (Bs.bounce > e) e = Bs.bounce;
      f = 0.5F * (f + Bs.friction);
    } else {
      c.rb = rbV(0.0F, 0.0F, 0.0F);
    }
    c.kn = kn > 1e-9F ? kn : 1e-9F;
    c.vnPred = rbDot(vrel, c.n);
    c.bounceTarget = -c.vnPred > bounceThreshold ? -e * c.vnPred : 0.0F;
    // Coulomb friction coefficient from the authored 0..1 "Friction".
    c.mu = 0.05F + 0.95F * f;
    c.jn = c.jp = 0.0F;
    c.ft = rbV(0.0F, 0.0F, 0.0F);
    restoreContact(c);
    if (c.n.y > 0.5F) A.grounded = true;
    if (c.b >= 0 && c.n.y < -0.5F) steps[c.b].grounded = true;
  }
  auto applyImpulse = [&](RbContact& c, RbV P) {
    RbStep& A = steps[c.a];
    A.v = rbAdd(A.v, rbMul(P, A.invMass));
    A.w = rbAdd(A.w, rbMat(A.invIw, rbCross(c.ra, P)));
    if (c.b >= 0) {
      RbStep& Bs = steps[c.b];
      Bs.v = rbSub(Bs.v, rbMul(P, Bs.invMass));
      Bs.w = rbSub(Bs.w, rbMat(Bs.invIw, rbCross(c.rb, P)));
    }
  };
  auto relVel = [&](const RbContact& c) {
    const RbStep& A = steps[c.a];
    RbV v = rbAdd(A.v, rbCross(A.w, c.ra));
    if (c.b >= 0) {
      const RbStep& Bs = steps[c.b];
      v = rbSub(v, rbAdd(Bs.v, rbCross(Bs.w, c.rb)));
    }
    return v;
  };
  if(warmStart)for(auto& c:contacts)applyImpulse(c,rbAdd(rbMul(c.n,c.jn),c.ft));
  for (int it = 0; it < PHYS_ITERATIONS; ++it)
    for (int k = 0; k < nc; ++k) {
      RbContact& c = contacts[k];
      RbV vrel = relVel(c);
      const float vn = rbDot(vrel, c.n);
      float nj = c.jn + (c.bounceTarget - vn) / c.kn;
      if (nj < 0.0F) nj = 0.0F;
      const float dj = nj - c.jn;
      c.jn = nj;
      if (dj != 0.0F) applyImpulse(c, rbMul(c.n, dj));
      // friction, against whatever tangential slip is left
      vrel = relVel(c);
      const RbV vt = rbSub(vrel, rbMul(c.n, rbDot(vrel, c.n)));
      const float vtl2 = rbDot(vt, vt);
      if (vtl2 < 1e-14F) continue;
      const float vtl = sqrtf(vtl2);
      const RbV t = rbMul(vt, 1.0F / vtl);
      const RbStep& A = steps[c.a];
      float kt = A.invMass +
                 rbDot(rbCross(rbMat(A.invIw, rbCross(c.ra, t)), c.ra), t);
      if (c.b >= 0) {
        const RbStep& Bs = steps[c.b];
        kt += Bs.invMass +
              rbDot(rbCross(rbMat(Bs.invIw, rbCross(c.rb, t)), c.rb), t);
      }
      if (kt < 1e-9F) continue;
      RbV nf = rbAdd(c.ft, rbMul(t, -vtl / kt));
      const float lim = c.mu * c.jn;
      const float nfl2 = rbDot(nf, nf);
      if (nfl2 > lim * lim) nf = rbMul(nf, lim / sqrtf(nfl2));
      applyImpulse(c, rbSub(nf, c.ft));
      c.ft = nf;
    }
  // Split impulse: the overlap still left after the velocity solve is
  // removed through pseudo velocities that move the body and are then
  // forgotten, so pushing a body out of the ground never launches it.
  for (int it = 0; it < PHYS_POS_ITERATIONS; ++it)
    for (int k = 0; k < nc; ++k) {
      RbContact& c = contacts[k];
      RbStep& A = steps[c.a];
      const float vnNow = rbDot(relVel(c), c.n);
      const float remaining = c.depth - (vnNow - c.vnPred);
      const float target =
          remaining > PHYS_SLOP ? PHYS_BAUMGARTE * (remaining - PHYS_SLOP) : 0.0F;
      RbV vp = rbAdd(A.vp, rbCross(A.wp, c.ra));
      if (c.b >= 0) {
        const RbStep& Bs = steps[c.b];
        vp = rbSub(vp, rbAdd(Bs.vp, rbCross(Bs.wp, c.rb)));
      }
      float nj = c.jp + (target - rbDot(vp, c.n)) / c.kn;
      if (nj < 0.0F) nj = 0.0F;
      const float dj = nj - c.jp;
      c.jp = nj;
      if (dj == 0.0F) continue;
      const RbV P = rbMul(c.n, dj);
      A.vp = rbAdd(A.vp, rbMul(P, A.invMass));
      A.wp = rbAdd(A.wp, rbMat(A.invIw, rbCross(c.ra, P)));
      if (c.b >= 0) {
        RbStep& Bs = steps[c.b];
        Bs.vp = rbSub(Bs.vp, rbMul(P, Bs.invMass));
        Bs.wp = rbSub(Bs.wp, rbMat(Bs.invIw, rbCross(c.rb, P)));
      }
    }
#endif
  if(warmStart)for(const auto& c:contacts)if(c.history>=0) {
    auto& memory=contactHistory[c.history];memory.normalImpulse=c.jn;memory.friction=c.ft;
  }
  // A component sleeps together only after every member has met its authored
  // delay. A moving member resets the component's countdown, not its contacts.
  if(useIslands) {
    islandQuiet.assign(awakeCount,1);islandReady.assign(awakeCount,1);
    for(int si=0;si<awakeCount;++si) {
      const auto& s=steps[si];const auto& o=runtimeObjects[s.obj];const int root=islands.root(si);
      const bool quiet=s.grounded && rbDot(s.v,s.v)<PHYS_REST_SPEED2 && rbDot(s.w,s.w)<PHYS_REST_W2;
      if(!quiet)islandQuiet[root]=0;
      if(o.restFrames+1<everyFrames(o.data.physSleep))islandReady[root]=0;
    }
  }

  }
  CB::StageScope writebackScope(6);
  // --- 5. integrate and write back ------------------------------------------
  for (int si = 0; si < awakeCount; ++si) {
    RbStep& S = steps[si];
    RuntimeObject& o = runtimeObjects[S.obj];
    PhysBody& B = physBodies[S.slot];
    RbV v = S.v, w = S.w;
    // Rolling resistance: a ball on the ground loses its spin slowly (a
    // perfectly rigid ball on a perfectly rigid floor would roll forever),
    // and a light air drag keeps a spinning body from spinning for ever.
    if (S.grounded && S.sphere) w = rbMul(w, 1.0F - (0.004F + 0.03F * S.friction));
    w = rbMul(w, 0.998F);
    RbV x = rbAdd(rbAdd(S.x0, v), S.vp);
    float q[4] = {S.q0[0], S.q0[1], S.q0[2], S.q0[3]};
    rbIntegrate(q, rbAdd(w, S.wp));

    // Terrain edges are walls: reflect instead of clamping dead.
    const float wallX = TERRAIN_WIDTH * 0.5F - 0.5F;
    const float wallZ = TERRAIN_DEPTH * 0.5F - 0.5F;
    if (x.x > wallX) {
      x.x = wallX;
      if (v.x > 0.0F) v.x = -v.x * S.bounce;
    } else if (x.x < -wallX) {
      x.x = -wallX;
      if (v.x < 0.0F) v.x = -v.x * S.bounce;
    }
    if (x.z > wallZ) {
      x.z = wallZ;
      if (v.z > 0.0F) v.z = -v.z * S.bounce;
    } else if (x.z < -wallZ) {
      x.z = -wallZ;
      if (v.z < 0.0F) v.z = -v.z * S.bounce;
    }

    // Rest bookkeeping: near-still on something long enough -> sleep.
    const float speed2 = rbDot(v, v);
    const float spin2 = rbDot(w, w);CB::energy+=speed2+spin2;
    bool sleepNow = false;
    if (S.grounded && speed2 < PHYS_REST_SPEED2 && spin2 < PHYS_REST_W2 &&
        (!useIslands || islandQuiet[islands.root(si)])) {
      // Countdown length is per-object (Properties > Physics > Sleep after,
      // seconds); everyFrames tracks the measured frame time so the wait is
      // wall-clock true with vsync off too. On completion the counter pins
      // to PHYS_ASLEEP - the asleep test never re-derives the threshold.
      const int sleepAt = everyFrames(o.data.physSleep);
      if (o.restFrames < sleepAt) ++o.restFrames;
      if (o.restFrames >= sleepAt && (!useIslands || islandReady[islands.root(si)])) {
        o.restFrames = PHYS_ASLEEP;
        sleepNow = true;
        // Fast-path bodies stay on objMat while asleep - no settle rebuild,
        // so the shading that rode the tumble does not snap on the freeze.
      }
    } else {
      o.restFrames = 0;
    }
    if (sleepNow) {
      v = w = rbV(0.0F, 0.0F, 0.0F);
      // Keep the pose where the solver left it.
    }

    float R[9];
    rbQuatToMat(q, R);
    const RbV pos = rbSub(x, rbMat(R, rbV(B.comL[0], B.comL[1], B.comL[2])));
    float rot[3];
    rbMatToEuler(R, rot);
    const float dPos = fabsf(pos.x - o.data.position[0]) +
                       fabsf(pos.y - o.data.position[1]) +
                       fabsf(pos.z - o.data.position[2]);
    const float dRot = fabsf(rot[0] - o.data.rotation[0]) +
                       fabsf(rot[1] - o.data.rotation[1]) +
                       fabsf(rot[2] - o.data.rotation[2]);
    const bool turned = B.tumble && dRot > 1e-4F;
    o.data.position[0] = pos.x;
    o.data.position[1] = pos.y;
    o.data.position[2] = pos.z;
    // A body that does not tumble keeps its authored Euler angles exactly
    // (no conversion round trip for a quaternion that never moved).
    if (turned)
      for (int k = 0; k < 3; ++k) o.data.rotation[k] = rot[k];
    o.velocityX = v.x;
    o.velocityY = v.y;
    o.velocityZ = v.z;
    for (int k = 0; k < 4; ++k) B.q[k] = q[k];
    B.w[0] = w.x, B.w[1] = w.y, B.w[2] = w.z;
    o.spin[0] = w.x * (180.0F / PI);
    o.spin[1] = w.y * (180.0F / PI);
    o.spin[2] = w.z * (180.0F / PI);
    for (int k = 0; k < 3; ++k) {
      B.lastPos[k] = o.data.position[k];
      B.lastRot[k] = o.data.rotation[k];
      B.lastSpin[k] = o.spin[k];
    }
    if (dPos > 1e-5F || turned) {
      // Moving: eligible bodies get ONE local-space bake and ride objMat
      // from then on (refreshed in renderScene - no EE re-bake per frame);
      // the rest fall back to the legacy world-space rebuild.
      ObjectGeometry& g = objectGeometry[S.obj];
      if (!g.matrixMode && !o.dirty && physFastPathEligible(S.obj))
        rebuildObjectGeometry(S.obj, true);
      if (!g.matrixMode) o.dirty = true;
    }
  }
}

void TerrainGame::broadPhaseRefreshBaseline() const {
  bpFrame = g_frameStamp;
  // The active scene's backend: its own when a scene overrides one
  // (SCENE_BROADPHASES, Scene Preferences > Collision), else the project's.
  // A level load that changes it rebuilds the structure below.
#ifdef SCENE_BROADPHASE_PER_SCENE
  const auto kind = (BaselineTyra::BroadPhase::Kind)
      SCENE_BROADPHASES[currentScene >= 0 && currentScene < SCENE_COUNT ? currentScene : 0];
#else
  const auto kind = (BaselineTyra::BroadPhase::Kind)SCENE_BROADPHASE;
#endif
  const int n = (int)runtimeObjects.size();
  bool changed = false;
  if (bpGen != sceneGeneration || (int)bpCache.size() != n ||
      baselineBroadPhase.kind() != kind) {
    if (baselineBroadPhase.kind() != kind) baselineBroadPhase = BaselineTyra::BroadPhase(kind);
    baselineBroadPhase.clear();
    bpCache.assign((size_t)n, BroadPhaseCache());
    bpGen = sceneGeneration;
    changed = true;
  }
  // First bring every entry up to date and see whether the structure would
  // change at all: an object came or went, started or stopped moving, or a
  // placed box changed. A refresh boundary after a stage that moved nothing
  // (or only what is already moving) then costs this walk, not a rebuild.
  for (int i = 0; i < n; ++i) {
    const RuntimeObject& o = runtimeObjects[i];
    BroadPhaseCache& e = bpCache[(size_t)i];
    // physObstacle is the widest "can be touched" list (the walker's and the
    // sweep's objectCollides is a subset): every consumer re-applies its own.
    if (!o.active || !physObstacle(o.data)) {
      changed = changed || e.present;
      e.present = false;
      continue;
    }
    const float key[12] = {o.data.position[0], o.data.position[1],
                           o.data.position[2], o.data.rotation[0],
                           o.data.rotation[1], o.data.rotation[2],
                           o.data.scale[0],    o.data.scale[1],
                           o.data.scale[2],    o.data.modelYaw,
                           (float)o.data.model, (float)o.data.collision};
    bool same = e.valid;
    for (int k = 0; k < 12 && same; ++k) same = e.key[k] == key[k];
    if (!same) {
      // A first sighting is not a move: "moved" two frames ago, i.e. never.
      e.movedAt = e.valid ? g_frameStamp : g_frameStamp - 2u;
      for (int k = 0; k < 12; ++k) e.key[k] = key[k];
      e.valid = true;
      e.stale = true;
    }
    // Every collider, including sleeping and moving bodies, is spatially
    // indexed. Stage boundaries refresh transforms; a caller moving a collider
    // beyond the padding inside one stage must invalidate before querying.
    const bool moving = (o.data.physics && !physAsleep(o)) ||
                        g_frameStamp - e.movedAt <= 1u;
    if (e.stale) {
      broadPhaseBoxOf(o, e.box);
      e.stale = false;
      changed = true;
    }
    changed = changed || !e.present || moving != e.moving;
    e.present = true;
    e.moving = moving;
  }
  if (!changed) return;
  baselineBroadPhase.begin(n);
  for (int i = 0; i < n; ++i) {
    const BroadPhaseCache& e = bpCache[(size_t)i];
    if (e.present) baselineBroadPhase.set(i, e.box, e.moving);
  }
  baselineBroadPhase.commit();
}

void TerrainGame::broadPhaseNearBaseline(const Tyra::BroadBox& area,
                                 std::vector<int>& out) const {
  if (bpFrame != g_frameStamp) broadPhaseRefresh();
  if (bpVerifyAll) {  // the verify run's brute-force side
    out.clear();
    for (int i = 0; i < (int)runtimeObjects.size(); ++i) out.push_back(i);
    return;
  }
  baselineBroadPhase.queryBox(area, out);
  if (kBroadPhaseVerify) broadPhaseVerify(&area, nullptr, nullptr, 0.0F, out);
}

void TerrainGame::broadPhaseAlongBaseline(const float* a, const float* b, float radius,
                                  std::vector<int>& out) const {
  if (bpFrame != g_frameStamp) broadPhaseRefresh();
  if (bpVerifyAll) {
    out.clear();
    for (int i = 0; i < (int)runtimeObjects.size(); ++i) out.push_back(i);
    return;
  }
  baselineBroadPhase.querySegment(a, b, radius, out);
  if (kBroadPhaseVerify) broadPhaseVerify(nullptr, a, b, radius, out);
}
void TerrainGame::updateObjectPhysics(){CB::PhysicsScope scope;updateObjectPhysicsCandidate();}
void TerrainGame::broadPhaseRefresh() const {broadPhaseRefreshCandidate();}
void TerrainGame::broadPhaseNear(const Tyra::BroadBox& b,std::vector<int>& out) const {broadPhaseNearCandidate(b,out);}
void TerrainGame::broadPhaseAlong(const float*a,const float*b,float r,std::vector<int>& out) const {broadPhaseAlongCandidate(a,b,r,out);}

void TerrainGame::benchTick(){
 if(CB::finished)return;
#if TYRA_SOLVER_COMPARISON
 static bool checked=false;if(!checked){checked=true;FILE* verify=fopen("sat-verify.cfg","r");Tyra::vu0SatVerify=verify!=nullptr;if(verify)fclose(verify);if(Tyra::vu0SatVerify && !TYRA_TEMPORAL_SETTLE)CB::phase=12;printf("VUSAT mode=%s\n",Tyra::vu0SatVerify?"verify":"timing");CB::phase=12;if(!PhysicsPmu::calibrate()){CB::finished=true;printf("PHYSICSPMU calibration rejected\n");return;}if(!TyraSolverProbe::run() || !Vu0SatProbe::run() || !Vu0SatPrecision::run() || !Vu0SatStream::run()){CB::finished=true;return;}}
#endif
 if(CB::ready && CB::frame>=CB::total){CB::flush();++CB::phase;CB::ready=false;
  if(CB::phase>=14){CB::finished=true;printf("CB DONE phases=%d\n",CB::phase);fflush(stdout);return;}
  CB::configure();loadScene(0);CB::setup=true;
 }
 if(TYRA_TEMPORAL_SETTLE && CB::ready && CB::frame==CB::warm+CB::park){
  const int index=135;const auto& o=runtimeObjects[index];
  physPushAt(index,o.data.position[0],o.data.position[1],o.data.position[2],.12F,0,0);
 }
 if(CB::setup && !runtimeObjects.empty()){
  CB::configure();Tyra::vu0SatMetrics={};Tyra::vu0SatValidationErrors=0;Tyra::vu0SatValidation={};int found=0;
  for(int i=0;i<(int)runtimeObjects.size();++i){auto&o=runtimeObjects[i];
   int index=i-135;if(index<0 || index>=128)continue;
  bool enabled=index<CB::added;o.active=enabled;o.visible=enabled;
   float x,z,y;if(CB::layout){x=-1.5F+float(index%4);z=-48.0F+float((index/4)%4);y=.45F+float(index/16)*.92F;}
   else{x=-7.0F+float(index%8)*2.0F;z=-50.0F+float(index/8)*7.0F;y=.45F;}
   o.data.position[0]=x;o.data.position[1]=terrainHeightAt(x,z)+y;o.data.position[2]=z;
   o.data.rotation[0]=o.data.rotation[1]=o.data.rotation[2]=0;
   o.velocityX=o.velocityY=o.velocityZ=0;o.restFrames=0;o.dirty=true;++found;
  }
  if(found!=128){printf("CB ERROR body_count=%d\n",found);fflush(stdout);CB::finished=true;return;}
  physBodies.clear();physSlotOf.clear();physBodiesScene=-1;bpGen=~0u;bpFrame=~0u;broadPhase.clear();baselineBroadPhase.clear();
  g_frameClockLast=0;CB::frame=CB::phase<2?-300:0;CB::ready=true;CB::setup=false;
  printf("CB START phase=%d baseline=%d added=%d layout=%d rep=%d objects=%u\n",CB::phase,CB::baseline,CB::added,CB::layout,CB::repeat,(unsigned)runtimeObjects.size());fflush(stdout);
 }
}

}
