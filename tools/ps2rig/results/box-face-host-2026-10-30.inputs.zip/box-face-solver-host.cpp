#include <cassert>
#include <cmath>
#include <cstdio>
#include <vector>
#include "physics/vu0_sat.hpp"
namespace Vehicle_playground { namespace CB {inline int frame=0;inline bool finished=false;} namespace runtime_detail {
using RbV = Tyra::CollisionV3;
inline RbV rbV(float x, float y, float z) {
  RbV r;
  r.x = x, r.y = y, r.z = z;
  return r;
}
inline RbV rbAdd(RbV a, RbV b) { return rbV(a.x + b.x, a.y + b.y, a.z + b.z); }
inline RbV rbSub(RbV a, RbV b) { return rbV(a.x - b.x, a.y - b.y, a.z - b.z); }
inline RbV rbMul(RbV a, float s) { return rbV(a.x * s, a.y * s, a.z * s); }
inline float rbDot(RbV a, RbV b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline RbV rbCross(RbV a, RbV b) {
  return rbV(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z,
             a.x * b.y - a.y * b.x);
}
// 3x3 row-major
inline RbV rbMat(const float* m, RbV v) {
  return rbV(m[0] * v.x + m[1] * v.y + m[2] * v.z,
             m[3] * v.x + m[4] * v.y + m[5] * v.z,
             m[6] * v.x + m[7] * v.y + m[8] * v.z);
}
inline RbV rbMatT(const float* m, RbV v) {
  return rbV(m[0] * v.x + m[3] * v.y + m[6] * v.z,
             m[1] * v.x + m[4] * v.y + m[7] * v.z,
             m[2] * v.x + m[5] * v.y + m[8] * v.z);
}

}
}
#include "vehicle_contacts_probe.hpp"
namespace Vehicle_playground {using namespace runtime_detail;
struct RbContact {
  int other, history; // stable other object (-1 terrain), history record
  short a, b;     // RbStep indices; b = -1 is the world
  RbV n;          // pushes a away from b
  RbV p;          // world point
  float depth;
  float vnPred;   // normal velocity at creation (predicted motion)
  float bounceTarget;
  float mu;
  float kn;
  float jn, jp;
  RbV ft;         // accumulated friction impulse
  RbV ra, rb;
};
struct RbStep {int obj=0;float invMass=0,bounce=0,friction=0;bool grounded=false;RbV x1{},v{},w{},vp{},wp{};float invIw[9]{};};
namespace ZeroFrictionProbe {inline void record(bool,unsigned,unsigned){}}
constexpr int PHYS_ITERATIONS=6,PHYS_POS_ITERATIONS=3;constexpr float PHYS_SLOP=.005f,PHYS_BAUMGARTE=.5f;
void solve(std::vector<RbStep>& steps,std::vector<RbContact>& contacts){
 const int nc=int(contacts.size());const float bounceThreshold=0;const bool warmStart=false,skipZeroFriction=true;unsigned zeroFrictionSkipped=0;
 auto restoreContact=[](RbContact&){};
  for (int k = 0; k < nc; ++k) {
    RbContact& c = contacts[k];
    RbStep& A = steps[c.a];
    c.ra = rbSub(c.p, A.x1);
    RbV vrel = rbAdd(A.v, rbCross(A.w, c.ra));
    const RbV ca = rbCross(c.ra, c.n);
    float kn = A.invMass + rbDot(rbCross(rbMat(A.invIw, ca), c.ra), c.n);
    float e = A.bounce, f = A.friction;
    if (c.b >= 0) {
      RbStep& Bs = steps[c.b];
      c.rb = rbSub(c.p, Bs.x1);
      vrel = rbSub(vrel, rbAdd(Bs.v, rbCross(Bs.w, c.rb)));
      const RbV cb = rbCross(c.rb, c.n);
      kn += Bs.invMass + rbDot(rbCross(rbMat(Bs.invIw, cb), c.rb), c.n);
      if (Bs.bounce > e) e = Bs.bounce;
      f = 0.5F * (f + Bs.friction);
    } else {
      c.rb = rbV(0.0F, 0.0F, 0.0F);
    }
    c.kn = kn > 1e-9F ? kn : 1e-9F;
    c.vnPred = rbDot(vrel, c.n);
    c.bounceTarget = -c.vnPred > bounceThreshold ? -e * c.vnPred : 0.0F;
    // Coulomb friction coefficient from the authored 0..1 "Friction".
    c.mu = 0.05F + 0.95F * f;
    c.jn = c.jp = 0.0F;
    c.ft = rbV(0.0F, 0.0F, 0.0F);
    restoreContact(c);
    if (c.n.y > 0.5F) A.grounded = true;
    if (c.b >= 0 && c.n.y < -0.5F) steps[c.b].grounded = true;
  }
  auto applyImpulse = [&](RbContact& c, RbV P) {
    RbStep& A = steps[c.a];
    const RbV beforeA=A.v,beforeB=c.b>=0?steps[c.b].v:rbV(0,0,0);
    A.v = rbAdd(A.v, rbMul(P, A.invMass));
    A.w = rbAdd(A.w, rbMat(A.invIw, rbCross(c.ra, P)));
    if (c.b >= 0) {
      RbStep& Bs = steps[c.b];
      Bs.v = rbSub(Bs.v, rbMul(P, Bs.invMass));
      Bs.w = rbSub(Bs.w, rbMat(Bs.invIw, rbCross(c.rb, P)));
      if(VehicleContacts::isCar(A.obj) || VehicleContacts::isCar(Bs.obj))
        VehicleContacts::impulse(beforeA,beforeB,A.v,Bs.v,A.invMass,Bs.invMass,P);
    }
  };
  auto relVel = [&](const RbContact& c) {
    const RbStep& A = steps[c.a];
    RbV v = rbAdd(A.v, rbCross(A.w, c.ra));
    if (c.b >= 0) {
      const RbStep& Bs = steps[c.b];
      v = rbSub(v, rbAdd(Bs.v, rbCross(Bs.w, c.rb)));
    }
    return v;
  };
  if(warmStart)for(auto& c:contacts)applyImpulse(c,rbAdd(rbMul(c.n,c.jn),c.ft));
  for (int it = 0; it < PHYS_ITERATIONS; ++it)
    for (int k = 0; k < nc; ++k) {
      RbContact& c = contacts[k];
      RbV vrel = relVel(c);
      const float vn = rbDot(vrel, c.n);
      float nj = c.jn + (c.bounceTarget - vn) / c.kn;
      if (nj < 0.0F) nj = 0.0F;
      const float dj = nj - c.jn;
      c.jn = nj;
      if (dj != 0.0F) applyImpulse(c, rbMul(c.n, dj));
      // A zero-radius Coulomb disk and no prior tangent impulse imply zero
      // friction change. Keep all normal/position solves and contact records.
      if(skipZeroFriction&&c.jn==0&&c.ft.x==0&&c.ft.y==0&&c.ft.z==0){++zeroFrictionSkipped;continue;}
      // friction, against whatever tangential slip is left
      vrel = relVel(c);
      const RbV vt = rbSub(vrel, rbMul(c.n, rbDot(vrel, c.n)));
      const float vtl2 = rbDot(vt, vt);
      if (vtl2 < 1e-14F) continue;
      const float vtl = sqrtf(vtl2);
      const RbV t = rbMul(vt, 1.0F / vtl);
      const RbStep& A = steps[c.a];
      float kt = A.invMass +
                 rbDot(rbCross(rbMat(A.invIw, rbCross(c.ra, t)), c.ra), t);
      if (c.b >= 0) {
        const RbStep& Bs = steps[c.b];
        kt += Bs.invMass +
              rbDot(rbCross(rbMat(Bs.invIw, rbCross(c.rb, t)), c.rb), t);
      }
      if (kt < 1e-9F) continue;
      RbV nf = rbAdd(c.ft, rbMul(t, -vtl / kt));
      const float lim = c.mu * c.jn;
      const float nfl2 = rbDot(nf, nf);
      if (nfl2 > lim * lim) nf = rbMul(nf, lim / sqrtf(nfl2));
      applyImpulse(c, rbSub(nf, c.ft));
      c.ft = nf;
    }
  ZeroFrictionProbe::record(skipZeroFriction,unsigned(nc)*PHYS_ITERATIONS,zeroFrictionSkipped);
  // Split impulse: the overlap still left after the velocity solve is
  // removed through pseudo velocities that move the body and are then
  // forgotten, so pushing a body out of the ground never launches it.
  for (int it = 0; it < PHYS_POS_ITERATIONS; ++it)
    for (int k = 0; k < nc; ++k) {
      RbContact& c = contacts[k];
      RbStep& A = steps[c.a];
      const float vnNow = rbDot(relVel(c), c.n);
      const float remaining = c.depth - (vnNow - c.vnPred);
      const float target =
          remaining > PHYS_SLOP ? PHYS_BAUMGARTE * (remaining - PHYS_SLOP) : 0.0F;
      RbV vp = rbAdd(A.vp, rbCross(A.wp, c.ra));
      if (c.b >= 0) {
        const RbStep& Bs = steps[c.b];
        vp = rbSub(vp, rbAdd(Bs.vp, rbCross(Bs.wp, c.rb)));
      }
      float nj = c.jp + (target - rbDot(vp, c.n)) / c.kn;
      if (nj < 0.0F) nj = 0.0F;
      const float dj = nj - c.jp;
      c.jp = nj;
      if (dj == 0.0F) continue;
      const RbV P = rbMul(c.n, dj);
      A.vp = rbAdd(A.vp, rbMul(P, A.invMass));
      A.wp = rbAdd(A.wp, rbMat(A.invIw, rbCross(c.ra, P)));
      if (c.b >= 0) {
        RbStep& Bs = steps[c.b];
        Bs.vp = rbSub(Bs.vp, rbMul(P, Bs.invMass));
        Bs.wp = rbSub(Bs.wp, rbMat(Bs.invIw, rbCross(c.rb, P)));
      }
    }
}
}

#include "box_face_manifold.hpp"
using namespace Vehicle_playground;
struct RbCand {

  RbV n, p;

  float depth;

};



// Up to four points that span a contact patch: the deepest, the one

// farthest from it, the one farthest from that segment, then the one that

// adds the most area. A crate face flat on the ground keeps its four

// corners; a ring of cylinder rim points keeps a stable quadrilateral.

inline int rbReduce(const RbCand* in, int n, RbCand* out) {

  if (n <= 4) {

    for (int i = 0; i < n; ++i) out[i] = in[i];

    return n;

  }

  int pick[4] = {0, -1, -1, -1};

  for (int i = 1; i < n; ++i)

    if (in[i].depth > in[pick[0]].depth) pick[0] = i;

  float best = -1.0F;

  for (int i = 0; i < n; ++i) {

    const RbV d = rbSub(in[i].p, in[pick[0]].p);

    const float l = rbDot(d, d);

    if (l > best) best = l, pick[1] = i;

  }

  best = -1.0F;

  const RbV ab = rbSub(in[pick[1]].p, in[pick[0]].p);

  for (int i = 0; i < n; ++i) {

    const RbV c = rbCross(ab, rbSub(in[i].p, in[pick[0]].p));

    const float l = rbDot(c, c);

    if (l > best) best = l, pick[2] = i;

  }

  best = -1.0F;

  for (int i = 0; i < n; ++i) {

    if (i == pick[0] || i == pick[1] || i == pick[2]) continue;

    float area = 0.0F;

    for (int e = 0; e < 3; ++e) {

      const RbV a = rbSub(in[pick[e]].p, in[i].p);

      const RbV b = rbSub(in[pick[(e + 1) % 3]].p, in[i].p);

      const RbV c = rbCross(a, b);

      area += rbDot(c, c);

    }

    if (area > best) best = area, pick[3] = i;

  }

  int m = 0;

  for (int k = 0; k < 4; ++k) {

    if (pick[k] < 0) continue;

    bool dup = false;

    for (int e = 0; e < k; ++e) dup = dup || pick[e] == pick[k];

    if (!dup) out[m++] = in[pick[k]];

  }

  return m;

}



// The deepest face of a convex body (planes in its own centre-of-mass

// frame) that point `l` is inside; -1 when outside any of them.

inline int rbInsideHull(const float* lp, int np, RbV l, float* depth) {

  int best = -1;

  float bd = 1e30F;

  for (int k = 0; k < np; ++k) {

    const float* pl = lp + k * 4;

    const float d = pl[3] - (pl[0] * l.x + pl[1] * l.y + pl[2] * l.z);

    if (d <= 0.0F) return -1;

    if (d < bd) bd = d, best = k;

  }

  *depth = bd;

  return best;

}





struct Body {float radius=.866026f;const float* lp;int planes=6;};

struct Step {RbV x1,wv[8];int nv=8;float R1[9]={1,0,0,0,1,0,0,0,1};};

int corners(const Step&A,const Body&Ba,const Step&Bs,const Body&Bj,RbCand*out){RbCand cand[48];int n=0;

        for (int k = 0; k < A.nv && n < 48; ++k) {

          const RbV rel = rbSub(A.wv[k], Bs.x1);

          if (rbDot(rel, rel) > Bj.radius * Bj.radius) continue;

          float depth;

          const int f = rbInsideHull(Bj.lp,Bj.planes,rbMatT(Bs.R1,rel),&depth);

          if (f < 0) continue;

          const float* pl = Bj.lp + f * 4;

          cand[n].n = rbMat(Bs.R1, rbV(pl[0], pl[1], pl[2]));

          cand[n].p = A.wv[k];

          cand[n].depth = depth;

          ++n;

        }

        for (int k = 0; k < Bs.nv && n < 48; ++k) {

          const RbV rel = rbSub(Bs.wv[k], A.x1);

          if (rbDot(rel, rel) > Ba.radius * Ba.radius) continue;

          float depth;

          const int f = rbInsideHull(Ba.lp,Ba.planes,rbMatT(A.R1,rel),&depth);

          if (f < 0) continue;

          const float* pl = Ba.lp + f * 4;

          cand[n].n = rbMul(rbMat(A.R1, rbV(pl[0], pl[1], pl[2])), -1.0F);

          cand[n].p = Bs.wv[k];

          cand[n].depth = depth;

          ++n;

        }

 return rbReduce(cand,n,out);}


struct Box {
 Tyra::CollisionObb obb;RbV vertices[8],normals[3];
 Box(RbV c,RbV half,float yaw,float pitch=0){float y=cosf(yaw),sy=sinf(yaw),p=cosf(pitch),sp=sinf(pitch);
  normals[0]={y,0,-sy};normals[1]={sy*sp,p,y*sp};normals[2]={sy*p,-sp,y*p};
  obb.centre=c;float h[3]={half.x,half.y,half.z};for(int k=0;k<3;k++)obb.halfAxes[k]=rbMul(normals[k],h[k]);
  for(int j=0;j<8;j++){vertices[j]=c;for(int k=0;k<3;k++)vertices[j]=rbAdd(vertices[j],rbMul(obb.halfAxes[k],(j&(1<<k))?1.f:-1.f));}
 }
 Tyra::ConvexView view()const{return {vertices,8,normals,3,normals,3};}
};

int main(){using namespace Vehicle_playground;Tyra::vu0SatVerify=true;VehicleContacts::enabled=true;VehicleContacts::of={0,-1};
 Box a({.0001f,.9f,.0001f},{.5f,.5f,.5f},0),b({0,0,0},{.5f,.5f,.5f},0);Tyra::ConvexContact sat;
 assert(Tyra::convexMotionContact(a.view(),b.view(),{0,0,0},{0,0,0},sat));BoxFaceManifold::Point points[16];int n=BoxFaceManifold::clip(a.obb,b.obb,sat,points);assert(n==4);
 for(int mode=0;mode<2;mode++){
  std::vector<RbStep> bodies(2);bodies[0].obj=0;bodies[1].obj=1;bodies[0].x1=a.obb.centre;bodies[1].x1=b.obb.centre;
  bodies[0].invMass=1;for(int k:{0,4,8})bodies[0].invIw[k]=6;bodies[0].v={0,-.01f,0};
  std::vector<RbContact> contacts;
  if(mode){for(int k=0;k<n;k++){RbContact c{};c.a=0;c.b=1;c.n=points[k].n;c.p=points[k].p;c.depth=points[k].depth;contacts.push_back(c);}}
  else{
   float planes[]={1,0,0,.5f,-1,0,0,.5f,0,1,0,.5f,0,-1,0,.5f,0,0,1,.5f,0,0,-1,.5f};
   Body geometry;geometry.lp=planes;Step ca{},cb{};ca.x1=a.obb.centre;cb.x1=b.obb.centre;
   for(int k=0;k<8;k++){ca.wv[k]=a.vertices[k];cb.wv[k]=b.vertices[k];}
   RbCand legacy[4];int count=corners(ca,geometry,cb,geometry,legacy);assert(count==2);
   for(int k=0;k<count;k++){RbContact c{};c.a=0;c.b=1;c.n=legacy[k].n;c.p=legacy[k].p;c.depth=legacy[k].depth;contacts.push_back(c);}
  }
  VehicleContacts::current={};solve(bodies,contacts);auto&s=bodies[0];
  printf("mode=%d contacts=%u grounded=%d vy=%.9g pseudo_y=%.9g spin=%.9g\n",mode,unsigned(contacts.size()),s.grounded,s.v.y,s.vp.y,sqrtf(rbDot(s.w,s.w)));
  if(mode){assert(s.grounded);assert(fabsf(s.v.y)<.0001f);assert(s.vp.y>.03f);assert(sqrtf(rbDot(s.w,s.w))<.0001f);}
  else{assert(!s.grounded);assert(s.v.y<-.009f);assert(s.vp.y==0);}
 }
}
