
#pragma once
#include "debug/plane_sparse.hpp"
namespace Vehicle_playground { namespace PlaneSparseProbe {
using namespace runtime_detail;
inline unsigned calls=0,checked=0,errors=0,shapes=0,eligibleShapes=0,guardFallback=0;
inline bool classify(const float* planes,int count){
  const bool eligible=PlaneSparse::classify(planes,count);
  if(Tyra::vu0SatVerify && !CB::baseline){++shapes;eligibleShapes+=eligible;}
  return eligible;
}
inline unsigned bits(float x){unsigned u;memcpy(&u,&x,4);return u;}
inline int inside(const float* lp,int np,RbV l,float* depth,bool shape){
  if(CB::baseline)return rbInsideHull(lp,np,l,depth);
  const bool verify=Tyra::vu0SatVerify;
  if(verify)++calls;
  if(!shape)return rbInsideHull(lp,np,l,depth);
  if(!PlaneSparse::normalPoint(l)){
    if(verify)++guardFallback;
    return rbInsideHull(lp,np,l,depth);
  }
  float candidateDepth=0;const int candidate=PlaneSparse::inside(lp,l,&candidateDepth);
  if(!verify){if(candidate>=0)*depth=candidateDepth;return candidate;}
  ++checked;float referenceDepth=0;const int reference=rbInsideHull(lp,np,l,&referenceDepth);
  if(candidate!=reference || (candidate>=0 && bits(candidateDepth)!=bits(referenceDepth))){
    if(errors++<4)printf("PLANESPARSEDIFF point=%.9g,%.9g,%.9g face=%d/%d depth=%.9g/%.9g bits=%08x/%08x\n",l.x,l.y,l.z,candidate,reference,candidateDepth,referenceDepth,bits(candidateDepth),bits(referenceDepth));
  }
  // Shadow mode always returns the original result, even if the candidate fails.
  if(reference>=0)*depth=referenceDepth;return reference;
}
inline void flush(int phase){
  char name[64];snprintf(name,sizeof(name),"plane-sparse-%d.csv",phase);
  FILE* f=fopen(name,"wb");if(!f)++errors;
  if(f){fprintf(f,"phase,calls,checked,errors,shapes,eligible_shapes,guard_fallback\n%d,%u,%u,%u,%u,%u,%u\n",phase,calls,checked,errors,shapes,eligibleShapes,guardFallback);fclose(f);}
  printf("PLANESPARSE phase=%d calls=%u checked=%u errors=%u shapes=%u eligible_shapes=%u guard_fallback=%u file=%d\n",phase,calls,checked,errors,shapes,eligibleShapes,guardFallback,f!=nullptr);fflush(stdout);
  calls=checked=errors=shapes=eligibleShapes=guardFallback=0;
}
static_assert(sizeof(RbStep)==880,"Sparse flag must use existing bool padding");
} } // Vehicle_playground::PlaneSparseProbe
