
#pragma once
#include "debug/physics_pmu_probe.hpp"
#include <cstring>
#include <vector>
namespace Vehicle_playground { namespace SolverLayoutProbe {
using namespace runtime_detail;
struct alignas(16) CompactBody {
  float invMass, invIw[9];
  RbV v,w,vp,wp;
};
static_assert(sizeof(CompactBody)==96,"wire/layout contract");
inline CompactBody pack(const RbStep& s){
  CompactBody b;memset(&b,0,sizeof(b));b.invMass=s.invMass;
  for(int k=0;k<9;++k)b.invIw[k]=s.invIw[k];
  b.v=s.v;b.w=s.w;b.vp=s.vp;b.wp=s.wp;return b;
}
inline void scatter(RbStep& s,const CompactBody& b){s.v=b.v;s.w=b.w;s.vp=b.vp;s.wp=b.wp;}
template<class Body> __attribute__((noinline,noclone))
inline void core(Body* steps,RbContact* contacts,int nc){
  auto applyImpulse = [&](RbContact& c, RbV P) {
    Body& A = steps[c.a];
    A.v = rbAdd(A.v, rbMul(P, A.invMass));
    A.w = rbAdd(A.w, rbMat(A.invIw, rbCross(c.ra, P)));
    if (c.b >= 0) {
      Body& Bs = steps[c.b];
      Bs.v = rbSub(Bs.v, rbMul(P, Bs.invMass));
      Bs.w = rbSub(Bs.w, rbMat(Bs.invIw, rbCross(c.rb, P)));
    }
  };
  auto relVel = [&](const RbContact& c) {
    const Body& A = steps[c.a];
    RbV v = rbAdd(A.v, rbCross(A.w, c.ra));
    if (c.b >= 0) {
      const Body& Bs = steps[c.b];
      v = rbSub(v, rbAdd(Bs.v, rbCross(Bs.w, c.rb)));
    }
    return v;
  };

  for (int it = 0; it < PHYS_ITERATIONS; ++it)
    for (int k = 0; k < nc; ++k) {
      RbContact& c = contacts[k];
      RbV vrel = relVel(c);
      const float vn = rbDot(vrel, c.n);
      float nj = c.jn + (c.bounceTarget - vn) / c.kn;
      if (nj < 0.0F) nj = 0.0F;
      const float dj = nj - c.jn;
      c.jn = nj;
      if (dj != 0.0F) applyImpulse(c, rbMul(c.n, dj));
      // friction, against whatever tangential slip is left
      vrel = relVel(c);
      const RbV vt = rbSub(vrel, rbMul(c.n, rbDot(vrel, c.n)));
      const float vtl2 = rbDot(vt, vt);
      if (vtl2 < 1e-14F) continue;
      const float vtl = sqrtf(vtl2);
      const RbV t = rbMul(vt, 1.0F / vtl);
      const Body& A = steps[c.a];
      float kt = A.invMass +
                 rbDot(rbCross(rbMat(A.invIw, rbCross(c.ra, t)), c.ra), t);
      if (c.b >= 0) {
        const Body& Bs = steps[c.b];
        kt += Bs.invMass +
              rbDot(rbCross(rbMat(Bs.invIw, rbCross(c.rb, t)), c.rb), t);
      }
      if (kt < 1e-9F) continue;
      RbV nf = rbAdd(c.ft, rbMul(t, -vtl / kt));
      const float lim = c.mu * c.jn;
      const float nfl2 = rbDot(nf, nf);
      if (nfl2 > lim * lim) nf = rbMul(nf, lim / sqrtf(nfl2));
      applyImpulse(c, rbSub(nf, c.ft));
      c.ft = nf;
    }
  // Split impulse: the overlap still left after the velocity solve is
  // removed through pseudo velocities that move the body and are then
  // forgotten, so pushing a body out of the ground never launches it.
  for (int it = 0; it < PHYS_POS_ITERATIONS; ++it)
    for (int k = 0; k < nc; ++k) {
      RbContact& c = contacts[k];
      Body& A = steps[c.a];
      const float vnNow = rbDot(relVel(c), c.n);
      const float remaining = c.depth - (vnNow - c.vnPred);
      const float target =
          remaining > PHYS_SLOP ? PHYS_BAUMGARTE * (remaining - PHYS_SLOP) : 0.0F;
      RbV vp = rbAdd(A.vp, rbCross(A.wp, c.ra));
      if (c.b >= 0) {
        const Body& Bs = steps[c.b];
        vp = rbSub(vp, rbAdd(Bs.vp, rbCross(Bs.wp, c.rb)));
      }
      float nj = c.jp + (target - rbDot(vp, c.n)) / c.kn;
      if (nj < 0.0F) nj = 0.0F;
      const float dj = nj - c.jp;
      c.jp = nj;
      if (dj == 0.0F) continue;
      const RbV P = rbMul(c.n, dj);
      A.vp = rbAdd(A.vp, rbMul(P, A.invMass));
      A.wp = rbAdd(A.wp, rbMat(A.invIw, rbCross(c.ra, P)));
      if (c.b >= 0) {
        Body& Bs = steps[c.b];
        Bs.vp = rbSub(Bs.vp, rbMul(P, Bs.invMass));
        Bs.wp = rbSub(Bs.wp, rbMat(Bs.invIw, rbCross(c.rb, P)));
      }
    }
}

inline unsigned errors=0,cases=0;
inline int pending=-1;
inline std::vector<RbStep> original,full,expectedFull,expectedCompact;
inline Tyra::SolverBuffer<CompactBody> compact;
inline std::vector<RbContact> originalContacts,workContacts,fullContacts,compactContacts;
inline unsigned bits(float x){unsigned u;memcpy(&u,&x,4);return u;}
inline bool same(RbV a,RbV b){return bits(a.x)==bits(b.x)&&bits(a.y)==bits(b.y)&&bits(a.z)==bits(b.z);}
inline bool sameBody(const RbStep& a,const RbStep& b){return same(a.v,b.v)&&same(a.w,b.w)&&same(a.vp,b.vp)&&same(a.wp,b.wp);}
inline bool sameContact(const RbContact& a,const RbContact& b){return bits(a.jn)==bits(b.jn)&&bits(a.jp)==bits(b.jp)&&same(a.ft,b.ft);}
inline void run(const std::vector<RbStep>& steps,const std::vector<RbContact>& contacts,int phase,int frame){
  if(contacts.empty())return;
  const unsigned nb=steps.size(),nc=contacts.size();
  original=steps;originalContacts=contacts;compact.resize(nb);
  char name[96];snprintf(name,sizeof(name),"solver-layout-%d-%d.bin",phase,frame);
  FILE* f=fopen(name,"wb");if(!f){++errors;return;}
  const unsigned header[6]={0x534c5954u,1u,nb,nc,sizeof(RbStep),sizeof(RbContact)};
  fwrite(header,sizeof(header),1,f);
  for(const auto& s:steps){const auto b=pack(s);fwrite(&b,sizeof(b),1,f);}
  fwrite(contacts.data(),sizeof(RbContact),nc,f);fclose(f);
  printf("SOLVERLAYOUTCASE phase=%d frame=%d bodies=%u contacts=%u full_stride=%u compact_stride=%u contact_stride=%u\n",phase,frame,nb,nc,unsigned(sizeof(RbStep)),unsigned(sizeof(CompactBody)),unsigned(sizeof(RbContact)));
  // Every repeat restores identical prepared inputs outside timing. Compact
  // timings include gathering all hot fields and scattering four velocities.
  for(int repeat=0;repeat<4;++repeat)for(int order=0;order<2;++order){
    const int mode=order^(repeat&1);
    full=original;workContacts=originalContacts;
    if(!PhysicsPmu::enter(0)){++errors;return;}
    const auto first=PhysicsPmu::mark();
    if(mode){
      for(unsigned i=0;i<nb;++i)compact[i]=pack(original[i]);
      core(compact.data(),workContacts.data(),int(nc));
      for(unsigned i=0;i<nb;++i)scatter(full[i],compact[i]);
    }else core(full.data(),workContacts.data(),int(nc));
    const auto last=PhysicsPmu::mark();PhysicsPmu::leave();
    if((last.a|last.b)&0x80000000u)++errors;
    printf("SOLVERLAYOUT phase=%d frame=%d repeat=%d mode=%d ticks=%u im=%u dm=%u\n",phase,frame,repeat,mode,last.t-first.t,last.a-first.a,last.b-first.b);
    if(!repeat){if(mode){expectedCompact=full;compactContacts=workContacts;}else{expectedFull=full;fullContacts=workContacts;}}
  }
  pending=frame;++cases;fflush(stdout);
}
inline void after(const std::vector<RbStep>& steps,const std::vector<RbContact>& contacts,int phase,int frame){
  if(pending!=frame)return;pending=-1;unsigned referenceDiff=0,compactDiff=0;
  for(unsigned i=0;i<steps.size();++i){referenceDiff+=!sameBody(steps[i],expectedFull[i]);compactDiff+=!sameBody(steps[i],expectedCompact[i]);}
  for(unsigned i=0;i<contacts.size();++i){referenceDiff+=!sameContact(contacts[i],fullContacts[i]);compactDiff+=!sameContact(contacts[i],compactContacts[i]);}
  errors+=referenceDiff+compactDiff;
  printf("SOLVERLAYOUTCHECK phase=%d frame=%d reference_diff=%u compact_diff=%u errors=%u cases=%u\n",phase,frame,referenceDiff,compactDiff,errors,cases);fflush(stdout);
}
} } // Vehicle_playground::SolverLayoutProbe
