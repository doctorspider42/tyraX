#include "physics/convex_collision.hpp"
#include <vector>
#include <cstring>
#include <cstdio>
#include <cassert>
#include <random>
constexpr int PHYS_MAX_HULL_VERTS=24,PHYS_ITERATIONS=6,PHYS_POS_ITERATIONS=3;
constexpr float PHYS_SLOP=.005F,PHYS_BAUMGARTE=.5F;
using RbV = Tyra::CollisionV3;
inline RbV rbV(float x, float y, float z) {
  RbV r;
  r.x = x, r.y = y, r.z = z;
  return r;
}
inline RbV rbAdd(RbV a, RbV b) { return rbV(a.x + b.x, a.y + b.y, a.z + b.z); }
inline RbV rbSub(RbV a, RbV b) { return rbV(a.x - b.x, a.y - b.y, a.z - b.z); }
inline RbV rbMul(RbV a, float s) { return rbV(a.x * s, a.y * s, a.z * s); }
inline float rbDot(RbV a, RbV b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline RbV rbCross(RbV a, RbV b) {
  return rbV(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z,
             a.x * b.y - a.y * b.x);
}
// 3x3 row-major
inline RbV rbMat(const float* m, RbV v) {
  return rbV(m[0] * v.x + m[1] * v.y + m[2] * v.z,
             m[3] * v.x + m[4] * v.y + m[5] * v.z,
             m[6] * v.x + m[7] * v.y + m[8] * v.z);
}
inline RbV rbMatT(const float* m, RbV v) {
  return rbV(m[0] * v.x + m[3] * v.y + m[6] * v.z,
             m[1] * v.x + m[4] * v.y + m[7] * v.z,
             m[2] * v.x + m[5] * v.y + m[8] * v.z);
}

struct RbStep {
  int obj;
  int slot;
  bool asleep;     // a sleeping body taking part as an immovable partner
  bool grounded;   // something below carried it this frame
  bool sphere;
  float sphereR;
  float invMass;
  float bounce, friction;
  RbV x0, x1;      // centre of mass: start of frame, predicted
  float q0[4];
  float R0[9], R1[9];
  float invIw[9];
  RbV v, w;        // velocities being solved
  RbV vp, wp;      // split-impulse pseudo velocities (position only)
  int nv;
  RbV wv0[PHYS_MAX_HULL_VERTS];  // hull corners at the start pose
  RbV wv[PHYS_MAX_HULL_VERTS];   // ... and at the predicted pose
  Tyra::CollisionBounds bounds; // conservative current/linear-sweep envelope
  bool box;
  Tyra::CollisionObb obb;
};

struct RbContact {
  int other, history; // stable other object (-1 terrain), history record
  short a, b;     // RbStep indices; b = -1 is the world
  RbV n;          // pushes a away from b
  RbV p;          // world point
  float depth;
  float vnPred;   // normal velocity at creation (predicted motion)
  float bounceTarget;
  float mu;
  float kn;
  float jn, jp;
  RbV ft;         // accumulated friction impulse
  RbV ra, rb;
};

struct alignas(16) CompactBody {
  float invMass, invIw[9];
  RbV v,w,vp,wp;
};
static_assert(sizeof(CompactBody)==96,"wire/layout contract");
inline CompactBody pack(const RbStep& s){
  CompactBody b;memset(&b,0,sizeof(b));b.invMass=s.invMass;
  for(int k=0;k<9;++k)b.invIw[k]=s.invIw[k];
  b.v=s.v;b.w=s.w;b.vp=s.vp;b.wp=s.wp;return b;
}
inline void scatter(RbStep& s,const CompactBody& b){s.v=b.v;s.w=b.w;s.vp=b.vp;s.wp=b.wp;}
template<class Body> __attribute__((noinline,noclone))
inline void core(Body* steps,RbContact* contacts,int nc){
  auto applyImpulse = [&](RbContact& c, RbV P) {
    Body& A = steps[c.a];
    A.v = rbAdd(A.v, rbMul(P, A.invMass));
    A.w = rbAdd(A.w, rbMat(A.invIw, rbCross(c.ra, P)));
    if (c.b >= 0) {
      Body& Bs = steps[c.b];
      Bs.v = rbSub(Bs.v, rbMul(P, Bs.invMass));
      Bs.w = rbSub(Bs.w, rbMat(Bs.invIw, rbCross(c.rb, P)));
    }
  };
  auto relVel = [&](const RbContact& c) {
    const Body& A = steps[c.a];
    RbV v = rbAdd(A.v, rbCross(A.w, c.ra));
    if (c.b >= 0) {
      const Body& Bs = steps[c.b];
      v = rbSub(v, rbAdd(Bs.v, rbCross(Bs.w, c.rb)));
    }
    return v;
  };

  for (int it = 0; it < PHYS_ITERATIONS; ++it)
    for (int k = 0; k < nc; ++k) {
      RbContact& c = contacts[k];
      RbV vrel = relVel(c);
      const float vn = rbDot(vrel, c.n);
      float nj = c.jn + (c.bounceTarget - vn) / c.kn;
      if (nj < 0.0F) nj = 0.0F;
      const float dj = nj - c.jn;
      c.jn = nj;
      if (dj != 0.0F) applyImpulse(c, rbMul(c.n, dj));
      // friction, against whatever tangential slip is left
      vrel = relVel(c);
      const RbV vt = rbSub(vrel, rbMul(c.n, rbDot(vrel, c.n)));
      const float vtl2 = rbDot(vt, vt);
      if (vtl2 < 1e-14F) continue;
      const float vtl = sqrtf(vtl2);
      const RbV t = rbMul(vt, 1.0F / vtl);
      const Body& A = steps[c.a];
      float kt = A.invMass +
                 rbDot(rbCross(rbMat(A.invIw, rbCross(c.ra, t)), c.ra), t);
      if (c.b >= 0) {
        const Body& Bs = steps[c.b];
        kt += Bs.invMass +
              rbDot(rbCross(rbMat(Bs.invIw, rbCross(c.rb, t)), c.rb), t);
      }
      if (kt < 1e-9F) continue;
      RbV nf = rbAdd(c.ft, rbMul(t, -vtl / kt));
      const float lim = c.mu * c.jn;
      const float nfl2 = rbDot(nf, nf);
      if (nfl2 > lim * lim) nf = rbMul(nf, lim / sqrtf(nfl2));
      applyImpulse(c, rbSub(nf, c.ft));
      c.ft = nf;
    }
  // Split impulse: the overlap still left after the velocity solve is
  // removed through pseudo velocities that move the body and are then
  // forgotten, so pushing a body out of the ground never launches it.
  for (int it = 0; it < PHYS_POS_ITERATIONS; ++it)
    for (int k = 0; k < nc; ++k) {
      RbContact& c = contacts[k];
      Body& A = steps[c.a];
      const float vnNow = rbDot(relVel(c), c.n);
      const float remaining = c.depth - (vnNow - c.vnPred);
      const float target =
          remaining > PHYS_SLOP ? PHYS_BAUMGARTE * (remaining - PHYS_SLOP) : 0.0F;
      RbV vp = rbAdd(A.vp, rbCross(A.wp, c.ra));
      if (c.b >= 0) {
        const Body& Bs = steps[c.b];
        vp = rbSub(vp, rbAdd(Bs.vp, rbCross(Bs.wp, c.rb)));
      }
      float nj = c.jp + (target - rbDot(vp, c.n)) / c.kn;
      if (nj < 0.0F) nj = 0.0F;
      const float dj = nj - c.jp;
      c.jp = nj;
      if (dj == 0.0F) continue;
      const RbV P = rbMul(c.n, dj);
      A.vp = rbAdd(A.vp, rbMul(P, A.invMass));
      A.wp = rbAdd(A.wp, rbMat(A.invIw, rbCross(c.ra, P)));
      if (c.b >= 0) {
        Body& Bs = steps[c.b];
        Bs.vp = rbSub(Bs.vp, rbMul(P, Bs.invMass));
        Bs.wp = rbSub(Bs.wp, rbMat(Bs.invIw, rbCross(c.rb, P)));
      }
    }
}


unsigned bits(float f){unsigned u;memcpy(&u,&f,4);return u;}
bool same(RbV a,RbV b){return bits(a.x)==bits(b.x)&&bits(a.y)==bits(b.y)&&bits(a.z)==bits(b.z);}
bool check(std::vector<RbStep> full,std::vector<RbContact> contacts){
 std::vector<CompactBody> compact;for(const auto& b:full)compact.push_back(pack(b));auto other=contacts;
 core(full.data(),contacts.data(),int(contacts.size()));core(compact.data(),other.data(),int(other.size()));
 for(size_t i=0;i<full.size();++i){const auto&a=full[i];const auto&b=compact[i];if(!same(a.v,b.v)||!same(a.w,b.w)||!same(a.vp,b.vp)||!same(a.wp,b.wp))return false;}
 for(size_t i=0;i<contacts.size();++i){const auto&a=contacts[i];const auto&b=other[i];if(bits(a.jn)!=bits(b.jn)||bits(a.jp)!=bits(b.jp)||!same(a.ft,b.ft))return false;}
 return true;
}
int main(int argc,char**argv){
 for(int i=1;i<argc;++i){FILE*f=fopen(argv[i],"rb");assert(f);unsigned h[6];assert(fread(h,sizeof(h),1,f)==1);assert(h[0]==0x534c5954u&&h[1]==1&&h[4]==sizeof(RbStep)&&h[5]==sizeof(RbContact));
  std::vector<RbStep>b(h[2]);std::vector<RbContact>c(h[3]);for(auto&s:b){CompactBody hot;assert(fread(&hot,sizeof(hot),1,f)==1);s.invMass=hot.invMass;memcpy(s.invIw,hot.invIw,sizeof(s.invIw));scatter(s,hot);}assert(fread(c.data(),sizeof(RbContact),c.size(),f)==c.size());assert(fgetc(f)==EOF);fclose(f);assert(check(b,c));printf("Saved physical snapshot %s passed\n",argv[i]);}
 std::mt19937 rng(378619);std::uniform_real_distribution<float>u(-1,1);auto v=[&](){return rbV(u(rng),u(rng),u(rng));};
 for(int test=0;test<10000;++test){
  std::vector<RbStep>b(1+rng()%192);std::vector<RbContact>c(1+rng()%512);
  for(auto&s:b){s.invMass=(test%7)? .1F+fabsf(u(rng)):0;float m[9];for(float&x:m)x=u(rng);
   for(int r=0;r<3;++r)for(int col=0;col<3;++col){s.invIw[r*3+col]=0;for(int k=0;k<3;++k)s.invIw[r*3+col]+=m[r*3+k]*m[col*3+k];if(r==col)s.invIw[r*3+col]+=.05F;if(!s.invMass)s.invIw[r*3+col]=0;}
   s.v=rbMul(v(),.1F);s.w=rbMul(v(),.02F);s.vp=s.wp=rbV(0,0,0);}
  for(auto&x:c){x.a=short(rng()%b.size());x.b=rng()%3?short(rng()%b.size()):short(-1);if(x.b==x.a)x.b=-1;
   x.n=v();x.n=rbMul(x.n,1/sqrtf(rbDot(x.n,x.n)+1e-20F));x.ra=v();x.rb=v();x.depth=fabsf(u(rng))*.05F;x.mu=.05F+.9F*fabsf(u(rng));
   const auto&a=b[x.a];RbV vel=rbAdd(a.v,rbCross(a.w,x.ra));float kn=a.invMass+rbDot(rbCross(rbMat(a.invIw,rbCross(x.ra,x.n)),x.ra),x.n);
   if(x.b>=0){const auto&z=b[x.b];vel=rbSub(vel,rbAdd(z.v,rbCross(z.w,x.rb)));kn+=z.invMass+rbDot(rbCross(rbMat(z.invIw,rbCross(x.rb,x.n)),x.rb),x.n);}
   x.kn=std::max(1e-9F,kn);x.vnPred=rbDot(vel,x.n);x.bounceTarget=x.vnPred<-.03F?-x.vnPred*.2F:0;x.jn=x.jp=0;x.ft=rbV(0,0,0);
  }
  if(!check(b,c)){printf("Mismatch graph %d\n",test);return 1;}
 }
 printf("10000 full/compact graph comparisons passed bitwise, strides %u/%u contacts %u\n",unsigned(sizeof(RbStep)),unsigned(sizeof(CompactBody)),unsigned(sizeof(RbContact)));
}
