#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <vector>
#define TYRA_VEH_SUBSTEP_REUSE 1
namespace Tyra {inline bool vu0SatVerify=true;}
namespace Vehicle_playground {
constexpr int PHYS_ASLEEP=32767;
inline float g_frameDt=.04f,g_frameScale=2;
namespace CB {inline bool baseline=false,finished=false,ready=true;inline int frame=0;inline unsigned ticks(){static unsigned n;return ++n;}}
}
#include "F:/Projects/tyra-editor/.tmp/worktrees/ps2-collision/tools/ps2rig/unified_timeline_probe.hpp"
namespace Vehicle_playground {
struct Data {bool physics=true;float position[3]{},rotation[3]{},physSleep=.1f;};
struct Object {bool active=true;Data data;float velocityX=0,velocityY=0,velocityZ=0,spin[3]{};int restFrames=0;};
struct Body {float w[3]{},lastSpin[3]{};};
struct VehGatherCache {bool valid=false;};
struct Vehicle {bool active=true;float pos[3]{},speed=1,lateral=0,yaw=0,spin=0,damage=0;int gear=0,grounded=1;};
struct TerrainGame {
 std::vector<Object> runtimeObjects{1};std::vector<Body> physBodies{1};std::vector<int> physSlotOf{0};
 std::vector<VehGatherCache> vehGather_{1};Vehicle vehicles_[1];int vehicleCount_=1;unsigned sceneGeneration=1;
 bool vehSubStepRepeat_=false,vehSubStepMore_=false,gravity=true,quiet=false,wake=false;
 float vehFrameDt_=0,spinner=0,tutorial=0,objectDt=0,vehicleDt=0;int objectCalls=0,vehicleCalls=0,firstClicks=0,colliderBuilds=0;
 void broadPhaseInvalidate(){}
 void buildVehicleColliders(){++colliderBuilds;}
 void updateSpinners(){spinner+=g_frameDt;}
 void updateVehicleTutorial(float dt){tutorial+=dt;}
 void updateObjectPhysics(){
  ++objectCalls;objectDt=g_frameDt;auto& o=runtimeObjects[0];auto& b=physBodies[0];if(o.restFrames==PHYS_ASLEEP)return;
  if(gravity)o.velocityY-=9.81f*g_frameDt*g_frameDt;
  o.data.position[0]+=o.velocityX;o.data.position[1]+=o.velocityY;o.data.position[2]+=o.velocityZ;
  for(int a=0;a<3;++a){if(b.lastSpin[a]!=o.spin[a])b.w[a]=o.spin[a];o.data.rotation[a]+=b.w[a];b.lastSpin[a]=o.spin[a];}
  if(quiet){if(++o.restFrames>=int(o.data.physSleep/g_frameDt))o.restFrames=PHYS_ASLEEP;}else o.restFrames=0;
 }
 void updateVehicles(float h){vehicleDt=h;++vehicleCalls;if(!vehSubStepRepeat_)++firstClicks;vehicles_[0].pos[0]+=vehicles_[0].speed*h;
  if(wake && !vehSubStepMore_)runtimeObjects[0].restFrames=0;
 }
 void stepVehicles(float dt){int n=std::clamp(int(dt*50+.5f),1,4);for(int k=0;k<n;++k){vehSubStepRepeat_=k>0;vehSubStepMore_=k+1<n;updateVehicles(dt/n);}vehSubStepRepeat_=vehSubStepMore_=false;updateVehicleTutorial(dt);}
 void stepUnifiedTimeline(float);
};
#include "F:/Projects/tyra-editor/.tmp/tests/vu0-sat/unified-timeline-wrong-clock.inc"
}
using namespace Vehicle_playground;
void close(float actual,float expected){assert(std::fabs(actual-expected)<1e-6f);}
void reset(float dt){g_frameDt=dt;g_frameScale=dt*50;UnifiedTimeline::sleep.clear();UnifiedTimeline::generation=~0u;CB::baseline=false;}
int main(){
 reset(.04f);TerrainGame a;a.runtimeObjects[0].velocityX=.6f;a.runtimeObjects[0].spin[1]=.2f;a.stepUnifiedTimeline(.04f);
 close(a.runtimeObjects[0].data.position[0],.6f);close(a.runtimeObjects[0].data.rotation[1],.2f);
 close(a.runtimeObjects[0].velocityX,.6f);close(a.runtimeObjects[0].velocityY,-9.81f*.04f*.04f);
 close(a.runtimeObjects[0].data.position[1],-9.81f*.02f*.02f*3);
 close(a.runtimeObjects[0].spin[1],.2f);close(a.physBodies[0].w[1],.2f);
 close(a.spinner,.04f);close(a.tutorial,.04f);close(g_frameDt,.04f);assert(a.objectCalls==2 && a.vehicleCalls==2 && a.firstClicks==1 && a.colliderBuilds==1);
 reset(.04f);TerrainGame b;b.gravity=false;b.quiet=true;b.stepUnifiedTimeline(.04f);b.stepUnifiedTimeline(.04f);assert(b.runtimeObjects[0].restFrames!=PHYS_ASLEEP);b.stepUnifiedTimeline(.04f);assert(b.runtimeObjects[0].restFrames==PHYS_ASLEEP);
 reset(.04f);TerrainGame c;c.gravity=false;c.quiet=true;c.wake=true;c.stepUnifiedTimeline(.04f);assert(c.runtimeObjects[0].restFrames==0);
 reset(1.f/60);TerrainGame d;CB::baseline=true;for(int k=0;k<20;++k)d.stepUnifiedTimeline(1.f/60);
 reset(1.f/60);TerrainGame e;for(int k=0;k<20;++k)e.stepUnifiedTimeline(1.f/60);
 assert(std::memcmp(d.runtimeObjects[0].data.position,e.runtimeObjects[0].data.position,12)==0);
 assert(d.objectDt==e.objectDt && d.vehicleDt==e.vehicleDt);
 assert(d.objectCalls==e.objectCalls && d.vehicleCalls==e.vehicleCalls);
 // Explicit differing inputs reproduce the two API clock values observed on
 // PS2; the host FPU does not otherwise reproduce EE conversion rounding.
 reset(1.f/60);g_frameScale=std::nextafter(g_frameScale,0.f);TerrainGame f;CB::baseline=true;f.stepUnifiedTimeline(g_frameDt);
 reset(1.f/60);g_frameScale=std::nextafter(g_frameScale,0.f);TerrainGame g;g.stepUnifiedTimeline(g_frameDt);
 assert(f.objectDt!=f.vehicleDt);assert(f.objectDt==g.objectDt && f.vehicleDt==g.vehicleDt);
 assert(std::memcmp(f.runtimeObjects[0].data.position,g.runtimeObjects[0].data.position,12)==0);
 puts("PASS: actual shared-clock controller: analytic translation/rotation/gravity, sleep duration, wake, clock restoration, click/presentation cadence, nominal compatibility");
}
